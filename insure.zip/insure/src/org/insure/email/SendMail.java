package org.insure.email;

import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {
	private static final String a = "noreply@insurion.org";
	private static final String b = "Qwerty12";
	
	public static String getSiteUrl(Map<String, String> params){
		String host = params.get("servername");
		String port = params.get("serverport");
		String context = params.get("contextpath");
		String scheme = params.get("serverscheme");
		return scheme + "://" + host + ":" + port + context;
	}
	
	public void send(String toEmail, String subject, String text) {
		send(toEmail, subject, text, false);
	}

	public void send(String toEmail, String subject, String text, boolean isHtml) {
		// Sender's email ID needs to be mentioned
		String from = a;
		String pass = b;
		// Recipient's email ID needs to be mentioned.
		String host = "smtp.yandex.ru";

		// Get system properties
		Properties properties = System.getProperties();
		// Setup mail server
		//properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.user", from);
		properties.put("mail.smtp.password", pass);
		properties.put("mail.smtp.port", "465");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.ssl.enable", "true");
		
		properties.put("mail.smtp.socketFactory.port", "465");
		properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

		// Get the default Session object.
		Session session = Session.getDefaultInstance(properties);

		try {
			// Create a default MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress(from));

			// Set To: header field of the header.
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));

			// Set Subject: header field
			message.setSubject((subject == null || "".equals(subject.trim()))?"Important Insurion information!":subject);

			// Now set the actual message
			if(isHtml){
				message.setContent(text, "text/html; charset=utf-8");
			} else {
				message.setText(text);
			}

			// Send message
			Transport transport = session.getTransport("smtp");
			transport.connect(host, from, pass);
			transport.sendMessage(message, message.getAllRecipients());
			transport.close();
		} catch (MessagingException e) {
			System.out.println("sending email failed: " + e.toString());
			throw new RuntimeException(e);
		}
	}
}