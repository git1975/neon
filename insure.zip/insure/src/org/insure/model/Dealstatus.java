package org.insure.model;

import java.io.Serializable;
import javax.persistence.*;

import com.google.gson.annotations.Expose;


/**
 * The persistent class for the dealstatus database table.
 * 
 */
@Entity(name="dealstatus")
@NamedQueries({
@NamedQuery(name="Dealstatus.findAll", query="SELECT d FROM dealstatus d"),
@NamedQuery(name="Dealstatus.findById", query="SELECT d FROM dealstatus d  WHERE d.id = :id"),
@NamedQuery(name="Dealstatus.findByCode", query="SELECT d FROM dealstatus d  WHERE d.code = :code"),
})

public class Dealstatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Transient
	public static final String STATUS_EDIT = "EDIT";
	
	@Transient
	public static final String STATUS_INVEST = "INVEST";

	@Id
	@Expose
	private int id;

	@Expose
	private String code;

	@Expose
	private String name;

	public Dealstatus() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}