package org.insure.model;

import java.io.Serializable;
import java.math.BigDecimal;

import com.google.gson.annotations.Expose;

public class ReportCommission implements Serializable {
	private static final long serialVersionUID = 2311356714334102454L;
	
	@Expose
	private int id;
	
	@Expose
	private BigDecimal sum;
	
	@Expose
	private Integer month;
	
	@Expose
	private Integer year;

	public BigDecimal getSum() {
		return sum;
	}

	public void setSum(BigDecimal sum) {
		this.sum = sum;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
