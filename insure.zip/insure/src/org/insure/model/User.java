package org.insure.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.*;

import com.google.gson.annotations.Expose;

import java.util.Date;


/**
 * The persistent class for the user database table.
 * 
 */
@Entity(name="user")
@NamedQueries({
@NamedQuery(name="User.findAll", query="SELECT u FROM user u"),
@NamedQuery(name="User.findById", query="SELECT u FROM user u  WHERE u.id = :id"),
@NamedQuery(name="User.findByName", query="SELECT u FROM user u  WHERE u.name = :name"),
@NamedQuery(name="User.findByEmail", query="SELECT u FROM user u  WHERE u.email = :email"),
@NamedQuery(name="User.findByRegcode", query="SELECT u FROM user u  WHERE u.regcode = :regcode"),
@NamedQuery(name="User.deleteById", query="DELETE FROM user u WHERE u.id=:id")
})
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Expose
	private long id;

	@Transient
	@Expose
    private BigDecimal invest;
	
	@Transient
	@Expose
    private BigDecimal profit;

	@Transient
	@Expose
    private BigDecimal percent;

	@Expose
	private Integer admin;

	@Expose
	private String digest;

	@Expose
	private String firstname;

	@Expose
	private String lastname;

	@Temporal(TemporalType.TIMESTAMP)
	private Date lasttime;

	@Expose
	private String middlename;

	@Expose
	private String name;

	@Expose
	private String password;
	
	@Expose
	private String seed;

	@Expose
	private String regcode;

	@Expose
	private String status;
	
	@Expose
	private String email;
	
	//bi-directional many-to-one association to Client
	@ManyToOne
	@JoinColumn(name="idclient")
	@Expose
	private Client client;

	public User() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Integer getAdmin() {
		return this.admin;
	}

	public void setAdmin(Integer admin) {
		this.admin = admin;
	}

	public String getDigest() {
		return this.digest;
	}

	public void setDigest(String digest) {
		this.digest = digest;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Date getLasttime() {
		return this.lasttime;
	}

	public void setLasttime(Date lasttime) {
		this.lasttime = lasttime;
	}

	public String getMiddlename() {
		return this.middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRegcode() {
		return this.regcode;
	}

	public void setRegcode(String regcode) {
		this.regcode = regcode;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Client getClient() {
		return this.client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public BigDecimal getInvest() {
		return invest;
	}

	public void setInvest(BigDecimal invest) {
		this.invest = invest;
	}

	public BigDecimal getProfit() {
		return profit;
	}

	public void setProfit(BigDecimal profit) {
		this.profit = profit;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public BigDecimal getPercent() {
		return percent;
	}

	public void setPercent(BigDecimal percent) {
		this.percent = percent;
	}

	public String getSeed() {
		return seed;
	}

	public void setSeed(String seed) {
		this.seed = seed;
	}
}