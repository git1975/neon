package org.insure.model;

import java.io.Serializable;
import javax.persistence.*;

import com.google.gson.annotations.Expose;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the operation database table.
 * 
 */
@Entity(name="operation")
@NamedQueries({
	@NamedQuery(name="Operation.findAll", query="SELECT o FROM operation o ORDER BY o.createdate DESC"),
	@NamedQuery(name="Operation.findByIdClient", query="SELECT o FROM operation o WHERE o.id = :id ORDER BY o.createdate DESC"),
	@NamedQuery(name="Operation.findById", query="SELECT o FROM operation o WHERE o.id=:id")
})
public class Operation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id 
	@GeneratedValue
	@Expose
	private long id;
	
	@Expose
	private String comment;

	@Expose
	private BigDecimal cost;

	@Temporal(TemporalType.TIMESTAMP)
	@Expose
	private Date createdate;

	@Expose
	private String email;

	@Expose
	private String name;

	@Expose
	private String phone;

	@Expose
	private String status;
	
	@Expose
	private String login;
	
	@Expose
	private int type;
	
	@ManyToOne
	@JoinColumn(name="iduser")
	@Expose
	private User user;

	public Operation() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public BigDecimal getCost() {
		return this.cost;
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}