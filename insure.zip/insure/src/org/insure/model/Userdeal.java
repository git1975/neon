package org.insure.model;

import java.io.Serializable;

import javax.persistence.*;

import com.google.gson.annotations.Expose;


/**
 * The persistent class for the userdeals database table.
 * 
 */
@Entity
@Table(name="userdeals")
@NamedQueries({
	@NamedQuery(name="Userdeal.findAll", query="SELECT u FROM Userdeal u"),
	@NamedQuery(name="Userdeal.findById", query="SELECT u FROM Userdeal u  WHERE u.id = :id"),
	@NamedQuery(name="Userdeal.findByUserAndDeal", query="SELECT u FROM Userdeal u  WHERE u.user = :user AND u.deal = :deal"),
	@NamedQuery(name="Userdeal.findByUser", query="SELECT u FROM Userdeal u  WHERE u.user = :user ORDER BY u.deal.id DESC"),
	@NamedQuery(name="Userdeal.findByDeal", query="SELECT u FROM Userdeal u  WHERE u.deal = :deal")
})
public class Userdeal implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Expose
	private long id;
	
	@ManyToOne
	@JoinColumn(name="iddeal")
	@Expose
    private Deal deal;

	@ManyToOne
	@JoinColumn(name="iduser")
	@Expose
    private User user;

	public Userdeal() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Deal getDeal() {
		return deal;
	}

	public void setDeal(Deal deal) {
		this.deal = deal;
	}

}