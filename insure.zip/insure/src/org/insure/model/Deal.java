package org.insure.model;

import java.io.Serializable;
import javax.persistence.*;

import com.google.gson.annotations.Expose;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the deal database table.
 * 
 */
@Entity(name="deal")
@NamedQueries({
	@NamedQuery(name="Deal.findAll", query="SELECT d FROM deal d ORDER BY d.id DESC"),
	@NamedQuery(name="Deal.findById", query="SELECT d FROM deal d WHERE d.id = :id"),
	@NamedQuery(name="Deal.deleteById", query="DELETE FROM deal d WHERE d.id=:id")
})
public class Deal implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Expose
	private long id;
	
	@Transient
	@Expose
    private BigDecimal saldo;

	@Transient
	@Expose
    private BigDecimal invest;
	
	@Transient
	@Expose
    private BigDecimal profit;

	@Temporal(TemporalType.TIMESTAMP)
	@Expose
	private Date createdate;
	
	@Temporal(TemporalType.DATE)
	@Expose
	private Date begindate;
	
	@Temporal(TemporalType.DATE)
	@Expose
	private Date enddate;

	@Expose
	private String objectinsurance;

	@Expose
	private BigDecimal premium;

	@Expose
	private BigDecimal sum;

	@Expose
	private long term;

	@Expose
	private BigDecimal loss;
	
	@Expose
	private BigDecimal ourprem;
	
	//bi-directional many-to-one association to Client
	@ManyToOne
	@JoinColumn(name="idclient")
	@Expose
	private Client client;

	//bi-directional many-to-one association to Client
	@ManyToOne
	@JoinColumn(name="idcpty")
	@Expose
	private Client cpty;

	@ManyToOne
	@JoinColumn(name="status", referencedColumnName="id")
	@Expose
    private Dealstatus status;
	
	public Deal() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		if(createdate != null){
			this.createdate = createdate;
		}
	}

	public String getObjectinsurance() {
		return this.objectinsurance;
	}

	public void setObjectinsurance(String objectinsurance) {
		this.objectinsurance = objectinsurance;
	}

	public BigDecimal getPremium() {
		return this.premium;
	}

	public void setPremium(BigDecimal premium) {
		this.premium = premium;
	}

	public BigDecimal getSum() {
		return this.sum;
	}

	public void setSum(BigDecimal sum) {
		this.sum = sum;
	}

	public long getTerm() {
		return this.term;
	}

	public void setTerm(long term) {
		this.term = term;
	}

	public Client getClient() {
		return this.client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Client getCpty() {
		return this.cpty;
	}

	public void setCpty(Client cpty) {
		this.cpty = cpty;
	}

	public BigDecimal getSaldo() {
		return saldo;
	}

	public void setSaldo(BigDecimal saldo) {
		this.saldo = saldo;
	}

	public Date getBegindate() {
		return begindate;
	}

	public void setBegindate(Date begindate) {
		this.begindate = begindate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public Dealstatus getStatus() {
		return status;
	}

	public void setStatus(Dealstatus status) {
		this.status = status;
	}

	public BigDecimal getInvest() {
		return invest;
	}

	public void setInvest(BigDecimal invest) {
		this.invest = invest;
	}

	public BigDecimal getProfit() {
		return profit;
	}

	public void setProfit(BigDecimal profit) {
		this.profit = profit;
	}

	public BigDecimal getLoss() {
		return loss;
	}

	public void setLoss(BigDecimal loss) {
		this.loss = loss;
	}

	public BigDecimal getOurprem() {
		return ourprem;
	}

	public void setOurprem(BigDecimal ourprem) {
		this.ourprem = ourprem;
	}

}