package org.insure.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the accounting database table.
 * 
 */
@Entity(name="accounting")
@NamedQueries({
	@NamedQuery(name="Accounting.findAll", query="SELECT a FROM accounting a"),
	@NamedQuery(name="Accounting.findById", query="SELECT a FROM accounting a WHERE a.id = :id")
})
public class Accounting implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private BigDecimal amount;

	private String desc;

	@Temporal(TemporalType.TIMESTAMP)
	private Date dt;

	private int iddeal;

	private int iduser;

	@Temporal(TemporalType.DATE)
	private Date operdate;

	private String username;

	//bi-directional many-to-one association to Account
	@ManyToOne
	@JoinColumn(name="iddtaccount")
	private Account account1;

	//bi-directional many-to-one association to Account
	@ManyToOne
	@JoinColumn(name="idktaccount")
	private Account account2;

	public Accounting() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getDesc() {
		return this.desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Date getDt() {
		return this.dt;
	}

	public void setDt(Date dt) {
		this.dt = dt;
	}

	public int getIddeal() {
		return this.iddeal;
	}

	public void setIddeal(int iddeal) {
		this.iddeal = iddeal;
	}

	public int getIduser() {
		return this.iduser;
	}

	public void setIduser(int iduser) {
		this.iduser = iduser;
	}

	public Date getOperdate() {
		return this.operdate;
	}

	public void setOperdate(Date operdate) {
		this.operdate = operdate;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Account getAccount1() {
		return this.account1;
	}

	public void setAccount1(Account account1) {
		this.account1 = account1;
	}

	public Account getAccount2() {
		return this.account2;
	}

	public void setAccount2(Account account2) {
		this.account2 = account2;
	}

}