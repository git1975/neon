package org.insure.model;

import java.io.Serializable;
import javax.persistence.*;

import com.google.gson.annotations.Expose;


/**
 * The persistent class for the dictionary database table.
 * 
 */
@Entity(name="dictionary")
@NamedQueries({
	@NamedQuery(name="Dictionary.findAll", query="SELECT d FROM dictionary d"),
	@NamedQuery(name="Dictionary.findById", query="SELECT d FROM dictionary d  WHERE d.id = :id"),
	@NamedQuery(name="Dictionary.findByName", query="SELECT d FROM dictionary d  WHERE d.code = :code")
})
public class Dictionary implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Expose
	private long id;

	@Expose
	private String code;

	@Expose
	private String value;
	
	@Expose
	private String description;

	public Dictionary() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}