package org.insure.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the account database table.
 * 
 */
@Entity(name="account")
@NamedQueries({
	@NamedQuery(name="Account.findAll", query="SELECT a FROM account a"),
	@NamedQuery(name="Account.findById", query="SELECT a FROM account a WHERE a.id = :id"),
	@NamedQuery(name="Account.findByNumber", query="SELECT a FROM account a WHERE a.number = :number")
})
public class Account implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private String description;

	private String number;

	//bi-directional many-to-one association to Account
	@ManyToOne
	@JoinColumn(name="idparent")
	private Account account;

	//bi-directional many-to-one association to Account
	@OneToMany(mappedBy="account")
	private List<Account> accounts;

	//bi-directional many-to-one association to Accounting
	@OneToMany(mappedBy="account1")
	private List<Accounting> accountings1;

	//bi-directional many-to-one association to Accounting
	@OneToMany(mappedBy="account2")
	private List<Accounting> accountings2;

	public Account() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getNumber() {
		return this.number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public Account getAccount() {
		return this.account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public List<Account> getAccounts() {
		return this.accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public Account addAccount(Account account) {
		getAccounts().add(account);
		account.setAccount(this);

		return account;
	}

	public Account removeAccount(Account account) {
		getAccounts().remove(account);
		account.setAccount(null);

		return account;
	}

	public List<Accounting> getAccountings1() {
		return this.accountings1;
	}

	public void setAccountings1(List<Accounting> accountings1) {
		this.accountings1 = accountings1;
	}

	public Accounting addAccountings1(Accounting accountings1) {
		getAccountings1().add(accountings1);
		accountings1.setAccount1(this);

		return accountings1;
	}

	public Accounting removeAccountings1(Accounting accountings1) {
		getAccountings1().remove(accountings1);
		accountings1.setAccount1(null);

		return accountings1;
	}

	public List<Accounting> getAccountings2() {
		return this.accountings2;
	}

	public void setAccountings2(List<Accounting> accountings2) {
		this.accountings2 = accountings2;
	}

	public Accounting addAccountings2(Accounting accountings2) {
		getAccountings2().add(accountings2);
		accountings2.setAccount2(this);

		return accountings2;
	}

	public Accounting removeAccountings2(Accounting accountings2) {
		getAccountings2().remove(accountings2);
		accountings2.setAccount2(null);

		return accountings2;
	}

}