package org.insure.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.*;

import com.google.gson.annotations.Expose;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the client database table.
 * 
 */
@Entity(name="client")
@NamedQueries({
	@NamedQuery(name="Client.findAll", query="SELECT c FROM client c"),
	@NamedQuery(name="Client.findAllByCtp", query="SELECT c FROM client c WHERE c.ctp = :ctp ORDER BY c.id"),
	@NamedQuery(name="Client.findById", query="SELECT c FROM client c WHERE c.id = :id"),
	@NamedQuery(name="Client.deleteById", query="DELETE FROM client c WHERE c.id=:id")
})
public class Client implements Serializable {
	private static final long serialVersionUID = 1L;
	/**
	 * ��������
	 */
	public static final String INVESTOR = "I";
	/**
	 * ������ ������������ ��
	 */
	public static final String CLIENT_FL = "A";
	/**
	 * ������ ������������ ��
	 */
	public static final String CLIENT_UL = "B";

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Expose
	private long id;

	@Expose
	private String bankinfo;

	@Temporal(TemporalType.DATE)
	@Expose
	private Date createdate = new Date();

	@Expose
	private String ctp;

	@Expose
	private String dtp;

	@Expose
	private String dul;

	@Expose
	private String email;

	@Expose
	private String firstname;

	@Expose
	private String fullname;

	@Expose
	private String lastname;

	@Expose
	private String location;

	@Expose
	private String middlename;

	@Expose
	private String name;

	@Expose
	private String phone;

	@Expose
	private String position;

	@Expose
	private String sex;

	@Expose
	private String dulkem;
	
	@Temporal(TemporalType.DATE)
	@Expose
	private Date duldt = new Date();
	
	@Expose
	private String city;
	
	@Expose
	private String street;
	
	@Expose
	private String dom;
	
	@Expose
	private String flat;
	
	@Expose
	private String bankbic;
	
	@Expose
	private String bankacc;
	
	@Expose
	private String address1;
	@Expose
	private String address2;
	@Expose
	private String workname;
	@Expose
	private String workposition;
	@Expose
	private String workaddress;
	@Expose
	private String workphone;
	@Expose
	private String inn;
	@Expose
	private String ogrn;
	@Expose
	private String contactname;
	@Expose
	private String contactposition;
	
	@Transient
	@Expose
	private String fio;
	
	/**
	 * - ���-�� ������� ������
	 */
	@Transient
	@Expose
	private Integer riskpast;
	
	/**
	 * - ���-�� ������������� ������
	 */
	@Transient
	@Expose
	private Integer riskrealize;
	
	/**
	 * - ����� ���������� ������, ����� ���������� ������ ��������� ������
	 */
	@Transient
	@Expose
	private BigDecimal sumpremium;
	
	/**
	 * - ����� ������������ ������, ����� ������������ ������ �������� ������
	 */
	@Transient
	@Expose
	private BigDecimal sumloss;
	
	/**
	 * - ����������� �������, ����������� ������
	 */
	@Transient
	@Expose
	private BigDecimal lossness;
	
	//bi-directional many-to-one association to User
	@OneToMany(mappedBy="client")
	private List<User> users;

	public Client() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getBankinfo() {
		return this.bankinfo;
	}

	public void setBankinfo(String bankinfo) {
		this.bankinfo = bankinfo;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		if(createdate != null){
			this.createdate = createdate;
		}
	}

	public String getCtp() {
		return this.ctp;
	}

	public void setCtp(String ctp) {
		this.ctp = ctp;
	}

	public String getDtp() {
		return this.dtp;
	}

	public void setDtp(String dtp) {
		this.dtp = dtp;
	}

	public String getDul() {
		return this.dul;
	}

	public void setDul(String dul) {
		this.dul = dul;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getFullname() {
		return this.fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getMiddlename() {
		return this.middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPosition() {
		return this.position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public List<User> getUsers() {
		return this.users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public User addUser(User user) {
		getUsers().add(user);
		user.setClient(this);

		return user;
	}

	public User removeUser(User user) {
		getUsers().remove(user);
		user.setClient(null);

		return user;
	}

	public String getDulkem() {
		return dulkem;
	}

	public void setDulkem(String dulkem) {
		this.dulkem = dulkem;
	}

	public Date getDuldt() {
		return duldt;
	}

	public void setDuldt(Date duldt) {
		this.duldt = duldt;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getDom() {
		return dom;
	}

	public void setDom(String dom) {
		this.dom = dom;
	}

	public String getFlat() {
		return flat;
	}

	public void setFlat(String flat) {
		this.flat = flat;
	}

	public String getBankbic() {
		return bankbic;
	}

	public void setBankbic(String bankbic) {
		this.bankbic = bankbic;
	}

	public String getBankacc() {
		return bankacc;
	}

	public void setBankacc(String bankacc) {
		this.bankacc = bankacc;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getWorkname() {
		return workname;
	}

	public void setWorkname(String workname) {
		this.workname = workname;
	}

	public String getWorkposition() {
		return workposition;
	}

	public void setWorkposition(String workposition) {
		this.workposition = workposition;
	}

	public String getWorkaddress() {
		return workaddress;
	}

	public void setWorkaddress(String workaddress) {
		this.workaddress = workaddress;
	}

	public String getWorkphone() {
		return workphone;
	}

	public void setWorkphone(String workphone) {
		this.workphone = workphone;
	}

	public String getInn() {
		return inn;
	}

	public void setInn(String inn) {
		this.inn = inn;
	}

	public String getOgrn() {
		return ogrn;
	}

	public void setOgrn(String ogrn) {
		this.ogrn = ogrn;
	}

	public String getContactname() {
		return contactname;
	}

	public void setContactname(String contactname) {
		this.contactname = contactname;
	}

	public String getContactposition() {
		return contactposition;
	}

	public void setContactposition(String contactposition) {
		this.contactposition = contactposition;
	}

	public Integer getRiskpast() {
		return riskpast;
	}

	public void setRiskpast(Integer riskpast) {
		this.riskpast = riskpast;
	}

	public Integer getRiskrealize() {
		return riskrealize;
	}

	public void setRiskrealize(Integer riskrealize) {
		this.riskrealize = riskrealize;
	}

	public BigDecimal getSumpremium() {
		return sumpremium;
	}

	public void setSumpremium(BigDecimal sumpremium) {
		this.sumpremium = sumpremium;
	}

	@PostLoad
	public void getFio() {
		this.fio = this.lastname + " " + this.firstname + " " + this.middlename;
	}
	
	public String getFioString() {
		return this.fio;
	}

	public BigDecimal getSumloss() {
		return sumloss;
	}

	public void setSumloss(BigDecimal sumloss) {
		this.sumloss = sumloss;
	}

	public BigDecimal getLossness() {
		return lossness;
	}

	public void setLossness(BigDecimal lossness) {
		this.lossness = lossness;
	}

}