package org.insure.servlet;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.json.factory.JsonFactory;
import org.insure.json.wrapper.JsonWrapper;

import net.sf.json.JSONObject;

/**
 */
public class JsonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = LogManager.getLogger(JsonServlet.class.getName());
	
    public JsonServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		Map<String, String> params = new HashMap<String, String>();
		for(Enumeration<String> enm = request.getParameterNames(); enm.hasMoreElements();){
			String key = enm.nextElement();
			String v = URLDecoder.decode(request.getParameter(key), "utf8");
			v = "undefined".equals(v)?"":v;
			params.put(key, v);
		}
		log.info(request.getParameter("name") + ".doGet." + method);
		params.put("serverscheme", request.getScheme());
		params.put("servername", request.getServerName());
		params.put("serverport", String.valueOf(request.getServerPort()));
		params.put("contextpath", request.getContextPath());

		String json = "{}";
		JsonWrapper wrapper = null;
		try {
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			JsonFactory jf = new JsonFactory(response);
			wrapper = jf.getWrapper(method);
			if(wrapper != null){
				response.setContentType(wrapper.getContentType());
				json = wrapper.doMethod(params);
			} else {
				JSONObject obj = new JSONObject();
				obj.put("error", "Unknown method: " + method);
				json = obj.toString();
			}
			//Thread.sleep(1000);
			
			response.getWriter().write(json);
		} catch (Exception e) {
			e.printStackTrace();
			JSONObject obj = new JSONObject();
			obj.put("error", e.getMessage());
			log.error(obj.toString());
			response.getWriter().write(obj.toString());
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
