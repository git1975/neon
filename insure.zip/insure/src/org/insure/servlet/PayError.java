package org.insure.servlet;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Operation;
import org.insure.persistance.OperationController;

/**
 * Servlet implementation class PayError
 */
public class PayError extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger log = LogManager.getLogger(PayError.class.getName());
       
    public PayError() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		log.info("doGet...");
		response.sendRedirect(request.getContextPath() + "/error.html");
	}

	//{service_id=65520, partner_income=0.0, partner_id=249160, phone_number=, check=ada620f69c38b7ee9f03bebe32745ba5, email=denzorin1@gmail.com, system_income=0.0, name=?????�???�?????� ?????�???????? ???57, tid=42466495, comment=, order_id=57, type=spg_test, currency=RUB}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.info("doPost...");
		Map<String, String> params = new HashMap<String, String>();
		for(Enumeration<String> enm = request.getParameterNames(); enm.hasMoreElements();){
			String key = enm.nextElement();
			String v = URLDecoder.decode(request.getParameter(key), "utf8");
			v = "undefined".equals(v)?"":v;
			params.put(key, v);
		}
		
		log.info(params.toString());
		
		long id = Long.parseLong(params.get("order_id"));
		OperationController oc = new OperationController();
		Operation o = oc.getOperation(id);
		oc.errorOperation(o);
		
		//response.getWriter().append(params.toString());
		//response.sendRedirect(request.getContextPath() + "/error.html");
		this.doGet(request, response);
	}

}
