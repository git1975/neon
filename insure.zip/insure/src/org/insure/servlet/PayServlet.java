package org.insure.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.email.SendMail;
import org.insure.model.Dictionary;
import org.insure.model.Operation;
import org.insure.model.User;
import org.insure.persistance.AccountingController;
import org.insure.persistance.DictionaryController;
import org.insure.persistance.EntityFacade;
import org.insure.persistance.OperationController;

/**
 * Servlet implementation class PayServlet
 */
public class PayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger log = LogManager.getLogger(PayServlet.class.getName());

	public static final String ERR_1 = "-1";
	public static final String ERR_2 = "-2";
	public static final String ERR_3 = "-3";
	public static final String ERR_4 = "-4";
	public static final String ERR_5 = "-5";

	public PayServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.info("doGet...");
		try {
			request.setCharacterEncoding("UTF-8");
			Map<String, String> params = new HashMap<String, String>();
			for (Enumeration<String> enm = request.getParameterNames(); enm.hasMoreElements();) {
				String key = enm.nextElement();
				String v = URLDecoder.decode(request.getParameter(key), "UTF-8");
				// String v = request.getParameter(key);
				v = "undefined".equals(v) ? "" : v;
				params.put(key, v);
			}

			log.info(params.toString());
			boolean digedestOk = checkDigedest(params);

			long id = Long.parseLong(params.get("order_id"));
			OperationController oc = new OperationController();
			Operation o = oc.getOperation(id);

			if (o == null) {
				throw new ServletException(ERR_1);
			}
			if (!"INIT".equals(o.getStatus())) {
				throw new ServletException(ERR_2);
			}
			BigDecimal sum = new BigDecimal(params.get("system_income"));
			BigDecimal ourSum = new BigDecimal(params.get("partner_income"));
			// log.info("sum=" + sum + "; cost=" + o.getCost());
			if (sum.doubleValue() > 10000) {
				throw new ServletException(ERR_5);
			}

			if (sum.doubleValue() != o.getCost().doubleValue()) {
				throw new ServletException(ERR_3);
			}

			DictionaryController dc = new DictionaryController();
			Dictionary d = dc.getDictionary("checkPayCrypt");
			boolean b = true;
			if (d != null) {
				b = ("1".equals(d.getValue()));
			}

			if (b && !digedestOk) {
				throw new ServletException(ERR_4);
			}
			//oc.successOperation(o);

			createIncome(o, ourSum);
		} catch (Exception e) {
			e.printStackTrace();
			log.info(e.toString());
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			
			response.setContentLength(0);
					
			return;
		}

		response.sendRedirect(request.getContextPath() + "/success.html");
	}

	// service_id=65520, partner_id=249160, partner_income=8.5,
	// check=549dd4161237622668cde3a664264c35, test=1, system_income=10,
	// name=�������� �����, tid=97157969465, comment=, order_id=1, type=spg_test
	// http://85.141.222.43:8888/insure/error.html?comment=&phone_number=&name=%D0%92%D0%BD%D0%B5%D1%81%D0%B5%D0%BD%D0%B8%D0%B5+%D1%81%D1%80%D0%B5%D0%B4%D1%81%D1%82%D0%B2+%E2%84%9656&system_income=0.0&order_id=56&type=spg_test&email=denzorin1%40gmail.com&currency=RUB&partner_income=0.0&tid=42465991&service_id=65520&partner_id=249160&check=c320e5e4006c71aff45b5a562af43da7
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.info("doPost...");
		this.doGet(request, response);
	}

	/**
	 * �������� ��������, ��� ������� ��������, �������� email
	 * @param o
	 * @param ourSum
	 * @throws Exception
	 */
	private void createIncome(Operation o, BigDecimal ourSum) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		try {
			try {
				User u = o.getUser();
				if (u == null) {
					throw new Exception("User not found: " + o.getLogin());
				}
				AccountingController ac = new AccountingController();
				
				em.getTransaction().begin();
				
				ac.addAccounting(em, AccountingController.A0001, AccountingController.A0002, u.getId(), o.getCost());
				ac.addAccounting(em, AccountingController.A0011, AccountingController.A0010, u.getId(), ourSum);
				
				o.setStatus("OK");
				em.merge(o);
				//ac.addOneAccounting(u, AccountingController.A0001, AccountingController.A0002, o.getCost());
				//ac.addOneAccounting(u, AccountingController.A0011, AccountingController.A0010, ourSum);

				//�������� email
				DictionaryController dc = new DictionaryController();
				String withdrawEmail = dc.getDictionary("withdrawEmail").getValue();
				if (withdrawEmail != null && !"".equals(withdrawEmail)) {
					SendMail email = new SendMail();
					String title = String.format("�������� %s(%s)(%s)", "���������� �������", u.getName(), u.getName());
					String body = String.format("�������� %s(%s)(%s, %s, %s, %s). �����, ���: %s", "���������� �������",
							u.getName(), u.getName(), u.getEmail(), u.getClient().getFioString(),
							u.getClient().getFullname(), o.getCost());
					email.send(withdrawEmail, title, body);
				}
				em.getTransaction().commit();
			} catch (Exception e) {
				e.printStackTrace();
				em.getTransaction().rollback();
				log.error(e);
				throw e;
			}
		} finally {
			em.close();
		}
	}

	public static void main(String[] params) {
		String s = md5("93851953148�������� �����2491606552020spg_test8510019b82992f0d");
		System.out.println(s);
	}

	public static String md5(String d) {
		// String d = "66362302037��������
		// �����2491606552011spg_test8.51019b82992f0d";
		MessageDigest md;
		try {
			md = MessageDigest.getInstance("MD5");
			md.reset();
			md.update(d.getBytes("UTF-8"));
			BigInteger hash = new BigInteger(1, md.digest());
			String result = hash.toString(16);
			if ((result.length() % 2) != 0) {
				result = "0" + result;
			}
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	// tid=68076716396&name=%D0%A2%D0%B5%D1%81%D1%82%D0%BE%D0%B2%D1%8B%D0%B9+%D0%B7%D0%B0%D0%BA%D0%B0%D0%B7&comment=&partner_id=249160&service_id=65520&order_id=11
	// &type=spg_test&partner_income=8.5&system_income=10&test=1&check=a64aab1ec605943c8f4fb40ef8366f79
	// 6f00ddd4d8e3682423e8d1916eaa0032
	// md5('68076716396�������� �����2491606552011spg_test8.51019b82992f0d')
	// 9b82992f0d
	// tid + name + comment + partner_id +service_id + order_id + type + cost +
	// income_total +income + partner_income + system_income + command
	// +phone_number + email + result + resultStr + date_created + version +card
	// + recurrent_order_id + test + secret_key
	private String[] s = new String[] { "tid", "name", "comment", "partner_id", "service_id", "order_id", "type",
			"partner_income", "system_income", "test" };

	private boolean checkDigedest(Map<String, String> params) {
		String d = "";
		for (String item : s) {
			d = d + getParam(params, item);
		}
		// test
		// d = d + "1";
		log.info("d=" + d + "1234567890");
		// secr
		d = d + "9b82992f0d";
		String check = getParam(params, "check");
		String check2 = md5(d);
		log.info("check2=" + check2);
		// log.info("digest.their=" + check + "; digest.our=" + check2);
		if (check2.equals(check)) {
			return true;
		} else {
			return false;
		}
	}

	private String getParam(Map<String, String> params, String name) {
		if (params.get(name) != null) {
			return params.get(name);
		} else {
			return "";
		}
	}

}
