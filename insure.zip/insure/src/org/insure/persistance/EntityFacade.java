package org.insure.persistance;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.insure.model.Client;
import org.insure.model.Deal;
import org.insure.model.Dealstatus;
import org.insure.model.User;
import org.insure.model.Userdeal;

public class EntityFacade {
	private static final String LOCAL_UNIT_NAME = "local";
	private static final String PROD_UNIT_NAME = "production";

	private static final String sqlInitUser = "INSERT INTO user (name,password,status,regcode,email)VALUES(?,?,'INIT',?,?)";
	private static final String sqlInitUserUpd = "UPDATE user SET password=?, regcode=? WHERE name=? AND status='INIT'";
	private static final String sqlCommitUser = "UPDATE user SET status='REG' WHERE name=? AND regcode=?";
	// private static EntityManagerFactory emf =
	// Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
	private static EntityManagerFactory emf = null;

	private static String getHostName() {
		InetAddress ip;
		String hostname;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();
			return hostname;
		} catch (UnknownHostException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static EntityManagerFactory getEmFactory() {
		if (emf != null) {
			return emf;
		}
		String host = getHostName();
		if (host.indexOf("regruhosting") >= 0) {
			emf = Persistence.createEntityManagerFactory(PROD_UNIT_NAME);
		} else {
			emf = Persistence.createEntityManagerFactory(LOCAL_UNIT_NAME);
		}
		return emf;
	}

	/**
	 * �������� EntityManager � ��������� ����������
	 * 
	 * @return
	 */
	public static EntityManager createEntityManager() {
		EntityManager em = null;
		boolean b = false;
		int i = 0;
		while (!b && i < 2) {
			i++;
			em = getEmFactory().createEntityManager();
			Query q = em.createNativeQuery("SELECT 1");
			try {
				q.getSingleResult();
				b = true;
			} catch (Exception se) {
				b = false;
			}
		}

		return (em == null) ? (createEntityManager()) : em;
	}

	public User getUser(long iduser) throws Exception {
		EntityManager em = createEntityManager();
		User u = null;
		try {
			u = (User) em.createNamedQuery("User.findById").setParameter("id", iduser).getSingleResult();
			return u;
		} catch (NoResultException e) {
			return null;
		}
	}

	public User getUser(String name) throws Exception {
		EntityManager em = createEntityManager();
		User u = null;
		try {
			u = (User) em.createNamedQuery("User.findByName").setParameter("name", name).getSingleResult();
			return u;
		} catch (NoResultException e) {
			return null;
		}
	}

	public User getUserByEmail(String email) throws Exception {
		EntityManager em = createEntityManager();
		User u = null;
		try {
			u = (User) em.createNamedQuery("User.findByEmail").setParameter("email", email).getSingleResult();
			return u;
		} catch (NoResultException e) {
			return null;
		}
	}

	public User getUserByRegcode(String regcode) throws Exception {
		EntityManager em = createEntityManager();
		User u = null;
		try {
			u = (User) em.createNamedQuery("User.findByRegcode").setParameter("regcode", regcode).getSingleResult();
			return u;
		} catch (NoResultException e) {
			return null;
		}
	}

	public void updateUser(User user) throws Exception {
		EntityManager em = createEntityManager();

		// Create new user
		em.getTransaction().begin();
		user.setClient(em.merge(user.getClient()));
		em.merge(user);
		em.getTransaction().commit();

		em.close();
	}

	public void deleteUser(long id) throws Exception {
		EntityManager em = createEntityManager();

		User u = getUser(id);
		Client c = u.getClient();

		try {
			try {
				em.getTransaction().begin();
				Query q = em.createNamedQuery("User.deleteById");
				q.setParameter("id", id);
				q.executeUpdate();
				if (c != null) {
					q = em.createNamedQuery("Client.deleteById");
					q.setParameter("id", c.getId());
					q.executeUpdate();
				}
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				throw e;
			}
		} finally {
			em.close();
		}

	}

	public void checkUserClient(User u) throws Exception {
		EntityManager em = createEntityManager();

		if (u.getClient() != null) {
			return;
		}
		em.getTransaction().begin();
		Client c = new Client();
		c.setName(u.getName());
		c.setCtp("I");
		c.setCreatedate(new Date());
		em.persist(c);
		em.flush();
		u.setClient(c);
		em.merge(u);
		em.getTransaction().commit();
		u = getUser(u.getId());
	}

	public void addUserDeal(long iduser, long iddeal) throws Exception {
		EntityManager em = createEntityManager();

		User u = (User) em.createNamedQuery("User.findById").setParameter("id", iduser).getSingleResult();
		Deal d = (Deal) em.createNamedQuery("Deal.findById").setParameter("id", iddeal).getSingleResult();

		if (u == null) {
			throw new Exception("User not found: " + iduser);
		}
		if (d == null) {
			throw new Exception("Deal not found: " + iddeal);
		}
		if (!Dealstatus.STATUS_INVEST.equals(d.getStatus().getCode())) {
			throw new Exception("Wrong deal status: " + d.getStatus().getCode());
		}

		// Create new user
		em.getTransaction().begin();
		Userdeal ud = new Userdeal();
		ud.setDeal(d);
		ud.setUser(u);
		em.persist(ud);
		em.getTransaction().commit();

		em.close();
	}

	public void deleteUserDeal(long id) throws Exception {
		EntityManager em = createEntityManager();
		Userdeal ud = (Userdeal) em.createNamedQuery("Userdeal.findById").setParameter("id", id).getSingleResult();

		if (ud == null) {
			throw new Exception("Userdeal not found: " + id);
		}

		try {
			try {
				em.getTransaction().begin();
				em.remove(ud);
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				throw e;
			}
		} finally {
			em.close();
		}

		em.close();
	}

	public void deleteUserDeal(User u, Deal d) throws Exception {
		EntityManager em = createEntityManager();
		Userdeal ud = (Userdeal) em.createNamedQuery("Userdeal.findByUserAndDeal").setParameter("user", u)
				.setParameter("deal", d).getSingleResult();

		if (ud == null) {
			throw new Exception("Userdeal not found: " + u + ", " + d);
		}

		try {
			try {
				em.getTransaction().begin();
				em.remove(ud);
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				throw e;
			}
		} finally {
			em.close();
		}
	}

	public List<Client> getClients(String clientType) throws Exception {
		EntityManager em = createEntityManager();

		Query q = em.createNamedQuery("Client.findAllByCtp");
		q.setParameter("ctp", clientType);
		List<Client> result = q.getResultList();

		return result;
	}

	public Client getClient(long id) throws Exception {
		EntityManager em = createEntityManager();

		Client c = (Client) em.createNamedQuery("Client.findById").setParameter("id", id).getSingleResult();

		return c;
	}

	public List<User> getUsers() throws Exception {
		EntityManager em = createEntityManager();

		Query q = em.createNamedQuery("User.findAll");
		List<User> result = q.getResultList();

		return result;
	}

	public Deal getDeal(long id) throws Exception {
		EntityManager em = createEntityManager();

		Deal d = null;
		try {
			d = (Deal) em.createNamedQuery("Deal.findById").setParameter("id", id).getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			d = null;
		}

		return d;
	}

	public List<Deal> getDeals() throws Exception {
		EntityManager em = createEntityManager();

		Query q = em.createNamedQuery("Deal.findAll");
		List<Deal> result = q.getResultList();

		return result;
	}

	public List<Userdeal> getGetUserDealsByUser(User u) throws Exception {
		EntityManager em = createEntityManager();

		Query q = em.createNamedQuery("Userdeal.findByUser");
		q.setParameter("user", u);
		List<Userdeal> result = q.getResultList();

		return result;
	}

	public List<Userdeal> getGetUserDealsByDeal(Deal d) throws Exception {
		EntityManager em = createEntityManager();

		Query q = em.createNamedQuery("Userdeal.findByDeal");
		q.setParameter("deal", d);
		List<Userdeal> result = q.getResultList();

		return result;
	}

	public void updateClient(Client c) throws Exception {
		EntityManager em = createEntityManager();

		em.getTransaction().begin();
		em.merge(c);
		em.getTransaction().commit();

		em.close();
	}

	public void updateDeal(Deal d) throws Exception {
		EntityManager em = createEntityManager();

		em.getTransaction().begin();
		em.merge(d);
		em.getTransaction().commit();

		em.close();
	}

	/**
	 * ������ ������������ ������, �������� ���� ��������
	 * 
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public void investDeal(Deal d) throws Exception {
		EntityManager em = createEntityManager();

		em.getTransaction().begin();
		try {
			// ���� ������
			double ourprem = d.getOurprem().doubleValue();
			// ���������� ���� ������
			AccountingController af = new AccountingController();
			af.addAccountingDeal(em, AccountingController.A0005, AccountingController.A0007, d.getId(),
					BigDecimal.valueOf(ourprem));

			d.setStatus((Dealstatus) em.createNamedQuery("Dealstatus.findByCode").setParameter("code", "INVEST")
					.getSingleResult());
			em.merge(d);
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw e;
		}
		em.close();
	}

	/**
	 * ������� ������
	 * 
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public void closeDeal(Deal d) throws Exception {
		EntityManager em = createEntityManager();

		//
		// em.merge(d);
		//
		em.getTransaction().begin();
		try {
			em.merge(d);
			// ������� ���� ������������������ ����������
			Query q = em.createNamedQuery("Userdeal.findByDeal");
			q.setParameter("deal", d);
			List<Userdeal> investors = q.getResultList();
			for (Userdeal investor : investors) {
				// ����� ������
				BigDecimal sum = d.getSum();
				// ������
				double loss = d.getLoss().doubleValue();
				// ���� ������
				double ourprem = (d.getOurprem() == null) ? 0.0 : d.getOurprem().doubleValue();
				// ������ �������
				double premium = d.getPremium().doubleValue();
				// ������� ������ ����� ���������� �� ������
				// TODO - ��� �� ������ �����, ���� ����� ������ � �� ������
				BigDecimal saldo = getUserDealSaldo(investor.getUser().getId(), investor.getDeal().getId());
				// �������
				double percent = saldo.doubleValue() / sum.doubleValue();
				// ����� ������ ���������
				double profit = (premium - ourprem) * percent;
				// ����� ������ ���������
				double invLoss = loss * percent;
				profit = profit - invLoss;
				AccountingController af = new AccountingController();
				// ��� ���� ���������� �������� �������� �� ����� ������ �� ����
				// ������
				af.addAccounting(em, AccountingController.A0005, AccountingController.A0004, investor.getUser().getId(),
						investor.getDeal().getId(), BigDecimal.valueOf(profit));
				// ����� �������� �������� �� ����� ������ �� ���� �����������
				// �������� ���������
				af.addAccounting(em, AccountingController.A0004, AccountingController.A0002, investor.getUser().getId(),
						investor.getDeal().getId(), BigDecimal.valueOf(profit));
				// ����� ������ �������� �� ����� ���������� �� ���� �����������
				// �������� ���������
				af.addAccounting(em, AccountingController.A0003, AccountingController.A0002, investor.getUser().getId(),
						investor.getDeal().getId(), saldo);
				// ���������� ����� ������ �� ������
				af.addAccounting(em, AccountingController.A0005, AccountingController.A0006, investor.getUser().getId(),
						investor.getDeal().getId(), BigDecimal.valueOf(loss));
				// ���������� ���� ������
				// af.addAccounting(em, AccountingController.A0005,
				// AccountingController.A0007, investor.getUser().getId(),
				// investor.getDeal().getId(), BigDecimal.valueOf(ourprem));
			}
			d.setStatus((Dealstatus) em.createNamedQuery("Dealstatus.findByCode").setParameter("code", "CLOSE")
					.getSingleResult());
			em.merge(d);
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw e;
		}
		em.close();
	}

	public void deleteDeal(long id) throws Exception {
		EntityManager em = createEntityManager();

		try {
			try {
				em.getTransaction().begin();
				Query q = em.createNamedQuery("Deal.deleteById");
				q.setParameter("id", id);
				q.executeUpdate();
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				throw e;
			}
		} finally {
			em.close();
		}

	}

	public void deleteClient(long id) throws Exception {
		EntityManager em = createEntityManager();

		try {
			try {
				em.getTransaction().begin();
				Query q = em.createNamedQuery("Client.deleteById");
				q.setParameter("id", id);
				q.executeUpdate();
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				throw e;
			}
		} finally {
			em.close();
		}

	}

	public void changePwd(String name, String p1, String p2) throws Exception {
		User u = this.getUser(name);
		if (u == null) {
			throw new Exception("User not found");
		}
		if (!u.getPassword().equals(p1)) {
			throw new Exception("Password incorrect");
		}
		EntityManager em = createEntityManager();
		try {
			try {
				em.getTransaction().begin();
				u.setPassword(p2);
				u.setDigest("");
				em.merge(u);
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				throw e;
			}
		} finally {
			em.close();
		}
	}

	public BigDecimal[] getUserSaldos(String name) throws Exception {
		User u = this.getUser(name);

		EntityManager em = createEntityManager();
		AccountingController af = new AccountingController();
		BigDecimal s1 = af.getAccountSaldo(em, AccountingController.A0001, u);// ������
																				// ���������
																				// �������
		BigDecimal s2 = af.getAccountSaldo(em, AccountingController.A0002, u);// ��������
																				// ���
																				// ��������������
		BigDecimal s3 = af.getAccountSaldo(em, AccountingController.A0003, u);// �����������������
		BigDecimal s4 = af.getAccountKtTurnover(em, AccountingController.A0004, u.getId(), 0);// �����
																								// ���������
		BigDecimal s5 = af.getAccountSaldo(em, AccountingController.A0008, u);// ������
																				// ��
																				// �����
		BigDecimal s6 = af.getAccountSaldo(em, AccountingController.A0009, u);// ��������
		BigDecimal s7 = (s1.doubleValue() == 0) ? new BigDecimal("0.00")
				: new BigDecimal(s4.doubleValue() / s1.doubleValue() * 100);// ����������
																			// %

		BigDecimal[] result = new BigDecimal[] { s1, s2, s3, s4, s5, s6, s7 };
		return result;
	}
	
	public BigDecimal[] getSaldos() throws Exception {
		EntityManager em = createEntityManager();
		AccountingController af = new AccountingController();
		BigDecimal s1 = af.getAccountSaldo(em, AccountingController.A0001);
		BigDecimal s2 = af.getAccountSaldo(em, AccountingController.A0010);

		BigDecimal[] result = new BigDecimal[] { s1, s2 };
		return result;
	}

	public BigDecimal getAccountSaldo(String account, User u) throws Exception {
		EntityManager em = createEntityManager();
		AccountingController af = new AccountingController();
		BigDecimal saldo = af.getAccountSaldo(em, account, u);

		return saldo;
	}

	/**
	 * ������ - ����������������� ���������� �� ������
	 * 
	 * @param iduser
	 * @param iddeal
	 * @return
	 * @throws Exception
	 */
	public BigDecimal getUserDealSaldo(long iduser, long iddeal) throws Exception {
		EntityManager em = createEntityManager();
		AccountingController af = new AccountingController();
		BigDecimal s1 = af.getAccountKtTurnover(em, AccountingController.A0003, iduser, iddeal);

		return s1;
	}

	/**
	 * ����� �� ������
	 * 
	 * @param iduser
	 * @param iddeal
	 * @return
	 * @throws Exception
	 */
	public BigDecimal getUserDealProfit(Long iduser, Long iddeal) throws Exception {
		EntityManager em = createEntityManager();
		AccountingController af = new AccountingController();
		BigDecimal s1 = af.getAccountKtTurnover(em, AccountingController.A0004, iduser, iddeal);

		return s1;
	}

	public void addUserDealSaldo(long iduser, long iddeal, BigDecimal amount) throws Exception {
		EntityManager em = createEntityManager();
		AccountingController af = new AccountingController();
		try {
			try {
				em.getTransaction().begin();
				af.addAccounting(em, AccountingController.A0002, AccountingController.A0003, iduser, iddeal, amount);
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				throw e;
			}
		} finally {
			em.close();
		}
	}

	public Dealstatus getDealstatus(int id) throws Exception {
		EntityManager em = createEntityManager();
		Dealstatus result = null;
		try {
			result = (Dealstatus) em.createNamedQuery("Dealstatus.findById").setParameter("id", id).getSingleResult();
			return result;
		} catch (NoResultException e) {
			return null;
		}
	}

	public int getClientRiskpast(long id) throws Exception {
		BigInteger result = new BigInteger("0");
		EntityManager em = createEntityManager();
		try {
			Query q = em.createNativeQuery("select count(*) from deal where idclient=:id");
			q.setParameter("id", id);
			result = (BigInteger) q.getSingleResult();
		} catch (NoResultException e) {
			throw e;
		}

		return result.intValue();
	}

	public int getClientRiskrealize(long id) throws Exception {
		BigInteger result = new BigInteger("0");
		EntityManager em = createEntityManager();
		try {
			Query q = em.createNativeQuery("select count(*) from deal where idclient=:id and ifnull(loss, 0) > 0");
			q.setParameter("id", id);
			result = (BigInteger) q.getSingleResult();
		} catch (NoResultException e) {
			throw e;
		}

		return result.intValue();
	}

	public BigDecimal getClientSumpremium(long id) throws Exception {
		BigDecimal result = null;
		EntityManager em = createEntityManager();
		try {
			Query q = em.createNativeQuery("select sum(premium) from deal where idclient=:id ");
			q.setParameter("id", id);
			result = (BigDecimal) q.getSingleResult();
		} catch (NoResultException e) {
			throw e;
		}

		return (result == null) ? new BigDecimal("0.00") : result;
	}

	public BigDecimal getClientSumloss(long id) throws Exception {
		BigDecimal result = null;
		EntityManager em = createEntityManager();
		try {
			Query q = em.createNativeQuery("select sum(loss) from deal where idclient=:id ");
			q.setParameter("id", id);
			result = (BigDecimal) q.getSingleResult();
		} catch (NoResultException e) {
			throw e;
		}

		return (result == null) ? new BigDecimal("0.00") : result;
	}

	public BigDecimal getCptySumpremium(long id) throws Exception {
		BigDecimal result = null;
		EntityManager em = createEntityManager();
		try {
			Query q = em.createNativeQuery("select sum(premium) from deal where idcpty=:id ");
			q.setParameter("id", id);
			result = (BigDecimal) q.getSingleResult();
		} catch (NoResultException e) {
			throw e;
		}

		return (result == null) ? new BigDecimal("0.00") : result;
	}

	public BigDecimal getCptySumloss(long id) throws Exception {
		BigDecimal result = null;
		EntityManager em = createEntityManager();
		try {
			Query q = em.createNativeQuery("select sum(loss) from deal where idcpty=:id ");
			q.setParameter("id", id);
			result = (BigDecimal) q.getSingleResult();
		} catch (NoResultException e) {
			throw e;
		}

		return (result == null) ? new BigDecimal("0.00") : result;
	}
}
