package org.insure.persistance;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.insure.model.Operation;

public class OperationController {
	public List<Operation> getOperations() throws Exception {
		try {
			EntityManager em = EntityFacade.createEntityManager();

			Query q = em.createNamedQuery("Operation.findAll");
			List<Operation> result = q.getResultList();
			return result;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public List<Operation> getClientOperations(long id) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		try {
			Query q = em.createNamedQuery("Operation.findById");
			List<Operation> result = q.getResultList();
			return result;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public Operation getOperation(long id) {
		EntityManager em = EntityFacade.createEntityManager();
		try {
			Operation d = (Operation) em.createNamedQuery("Operation.findById").setParameter("id", id).getSingleResult();
			return d;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public long insertOperation(Operation o) {
		EntityManager em = EntityFacade.createEntityManager();

		em.getTransaction().begin();
		em.persist(o);
		em.getTransaction().commit();

		em.close();
		return o.getId();
	}
	
	public long errorOperation(Operation o) {
		EntityManager em = EntityFacade.createEntityManager();

		em.getTransaction().begin();
		o.setStatus("ERROR");
		em.merge(o);
		em.getTransaction().commit();

		em.close();
		return o.getId();
	}
	
	public long successOperation(Operation o) {
		EntityManager em = EntityFacade.createEntityManager();

		em.getTransaction().begin();
		o.setStatus("OK");
		em.merge(o);
		em.getTransaction().commit();

		em.close();
		return o.getId();
	}
}
