package org.insure.persistance;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import org.apache.commons.lang.RandomStringUtils;

public class PasswordGenerator {
	public static String get(){
		return RandomStringUtils.random(8, false, true);
	}
	
	public static String getSha256(String s) throws NoSuchAlgorithmException{
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hash = digest.digest(s.getBytes(StandardCharsets.UTF_8));
		return hexEncode(hash);
	}
	
	public static String getSeed() throws NoSuchAlgorithmException{
		return hexEncode(SecureRandom.getInstance("SHA1PRNG").generateSeed(64));
	}
	
	public static String hexEncode(byte[] aInput) {
		StringBuilder result = new StringBuilder();
		char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
		for (int idx = 0; idx < aInput.length; ++idx) {
			byte b = aInput[idx];
			result.append(digits[(b & 0xf0) >> 4]);
			result.append(digits[b & 0x0f]);
		}
		return result.toString();
	}
}
