package org.insure.persistance;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.insure.model.Dictionary;

public class DictionaryController {
	public List<Dictionary> getDictionaries() throws Exception {
		try {
			EntityManager em = EntityFacade.createEntityManager();

			Query q = em.createNamedQuery("Dictionary.findAll");
			List<Dictionary> result = q.getResultList();
			return result;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public Dictionary getDictionary(String code) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		try {
			Dictionary d = (Dictionary) em.createNamedQuery("Dictionary.findByName").setParameter("code", code).getSingleResult();
			return d;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public Dictionary getDictionary(long id) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		try {
			Dictionary d = (Dictionary) em.createNamedQuery("Dictionary.findById").setParameter("id", id).getSingleResult();
			return d;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public void updateDictionary(Dictionary d) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();

		em.getTransaction().begin();
		em.merge(d);
		em.getTransaction().commit();

		em.close();
	}
}
