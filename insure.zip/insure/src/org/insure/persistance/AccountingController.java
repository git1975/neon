package org.insure.persistance;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.insure.model.ReportCommission;
import org.insure.model.User;

public class AccountingController {
	/**
	 * ��������� ���� �����
	 */
	public static final String A0001 = "A0001";
	/**
	 * ����������� �������� ���������
	 */
	public static final String A0002 = "A0002";
	/**
	 * ���� ����������
	 */
	public static final String A0003 = "A0003";
	/**
	 * ���� ������ �� ����������
	 */
	public static final String A0004 = "A0004";
	/**
	 * ���� ������
	 */
	public static final String A0005 = "A0005";
	/**
	 * ���� ������� �� �����
	 */
	public static final String A0006 = "A0006";
	/**
	 * ���� �������� Insurion �� �����
	 */
	public static final String A0007 = "A0007";
	/**
	 * ���� ������� �� �����
	 */
	public static final String A0008 = "A0008";
	/**
	 * ���� ���������� �������
	 */
	public static final String A0009 = "A0009";
	/**
	 * ����� �� ���������� (� ������ �������� �����)
	 */
	public static final String A0010 = "A0010";
	/**
	 * ���� �����-����������
	 */
	public static final String A0011 = "A0011";

	private static final String sqlAddAccounting = "INSERT INTO accounting (iddtaccount,idktaccount,iduser,iddeal,amount,operdate)VALUES"
			+ "((select id from account where number=?), (select id from account where number=?),?,?,?,now())";

	private static final String sqlAddAccounting2 = "INSERT INTO accounting (iddtaccount,idktaccount,iduser,amount,operdate)VALUES"
			+ "((select id from account where number=?), (select id from account where number=?),?,?,now())";

	private static final String sqlAddAccounting3 = "INSERT INTO accounting (iddtaccount,idktaccount,iddeal,amount,operdate)VALUES"
			+ "((select id from account where number=?), (select id from account where number=?),?,?,now())";

	private static final String sqlSaldo = "SELECT a.isactive*(ifnull((SELECT sum(ifnull(amount, 0)) FROM accounting WHERE iduser=? AND idktaccount=a.id), 0) -"
			+ "ifnull((SELECT sum(ifnull(amount, 0)) FROM accounting WHERE iduser=? AND iddtaccount=a.id), 0)) saldo from account a where a.number = ?";
	
	private static final String sqlSaldoFull = "SELECT a.isactive*(ifnull((SELECT sum(ifnull(amount, 0)) FROM accounting WHERE idktaccount=a.id), 0) -"
			+ "ifnull((SELECT sum(ifnull(amount, 0)) FROM accounting WHERE iddtaccount=a.id), 0)) saldo from account a where a.number = ?";

	private static final String sqlDtSaldo = "SELECT a.isactive*(ifnull((SELECT sum(ifnull(amount, 0)) FROM accounting WHERE iduser=? AND iddtaccount=a.id), 0)) saldo "
			+ "from account a where a.number = ?";

	private static final String sqlKtSaldo = "SELECT a.isactive*(ifnull((SELECT sum(ifnull(amount, 0)) FROM accounting WHERE iduser=? AND idktaccount=a.id), 0)) saldo "
			+ "from account a where a.number = ?";

	private static final String sqlUserDealSaldo = "SELECT a.isactive*(ifnull((SELECT sum(ifnull(amount, 0)) FROM accounting WHERE (iduser=? OR ? = 0) "
			+ "AND (iddeal=? OR ? = 0) AND idktaccount=a.id), 0)) - ifnull((SELECT sum(ifnull(amount, 0)) FROM accounting WHERE (iduser=? OR ? = 0) "
			+ "AND (iddeal=? OR ? = 0) AND iddtaccount=a.id), 0) " + "saldo from account a where a.number = ?";

	private static final String sqlUserDealKtTurnover = "SELECT a.isactive*(ifnull((SELECT sum(ifnull(amount, 0)) FROM accounting WHERE (iduser=? OR ? = 0) "
			+ "AND (iddeal=? OR ? = 0) AND idktaccount=a.id), 0)) saldo from account a where a.number = ?";

	private static final String sqlMonthSaldos = "SELECT ifnull(sum(ifnull(amount, 0)), 0) sum, month(operdate) m, year(operdate) y FROM accounting "
			+ "WHERE idktaccount=(select id from account where number=?) group by 2, 3";

	public BigDecimal getAccountSaldo(EntityManager em, String account, User u) {
		Query q = em.createNativeQuery(sqlSaldo);
		q.setParameter(1, u.getId());
		q.setParameter(2, u.getId());
		q.setParameter(3, account);
		BigDecimal saldo = (BigDecimal) q.getSingleResult();

		return saldo;
	}
	
	public BigDecimal getAccountSaldo(EntityManager em, String account) {
		Query q = em.createNativeQuery(sqlSaldoFull);
		q.setParameter(1, account);
		BigDecimal saldo = (BigDecimal) q.getSingleResult();

		return saldo;
	}

	public BigDecimal getAccountKtSaldo(EntityManager em, String account, User u) {
		Query q = em.createNativeQuery(sqlKtSaldo);
		q.setParameter(1, u.getId());
		q.setParameter(2, account);
		BigDecimal saldo = (BigDecimal) q.getSingleResult();

		return saldo;
	}

	public BigDecimal getAccountDtSaldo(EntityManager em, String account, User u) {
		Query q = em.createNativeQuery(sqlDtSaldo);
		q.setParameter(1, u.getId());
		q.setParameter(2, account);
		BigDecimal saldo = (BigDecimal) q.getSingleResult();

		return saldo;
	}

	public BigDecimal getAccountSaldo(EntityManager em, String account, long iduser, long iddeal) {
		Query q = em.createNativeQuery(sqlUserDealSaldo);
		q.setParameter(1, iduser);
		q.setParameter(2, iduser);
		q.setParameter(3, iddeal);
		q.setParameter(4, iddeal);
		q.setParameter(5, iduser);
		q.setParameter(6, iduser);
		q.setParameter(7, iddeal);
		q.setParameter(8, iddeal);
		q.setParameter(9, account);
		BigDecimal saldo = (BigDecimal) q.getSingleResult();

		return saldo;
	}

	/*
	 * public BigDecimal getAccountSaldo(EntityManager em, String account, User
	 * u, Deal d){ Query q = em.createNativeQuery(sqlUserDealSaldo);
	 * q.setParameter(1, (u == null)?0:u.getId()); q.setParameter(2, (u ==
	 * null)?0:u.getId()); q.setParameter(3, (d == null)?0:d.getId());
	 * q.setParameter(4, (d == null)?0:d.getId()); q.setParameter(5, (u ==
	 * null)?0:u.getId()); q.setParameter(6, (u == null)?0:u.getId());
	 * q.setParameter(7, (d == null)?0:d.getId()); q.setParameter(8, (d ==
	 * null)?0:d.getId()); q.setParameter(9, account); BigDecimal saldo =
	 * (BigDecimal)q.getSingleResult();
	 * 
	 * return saldo; }
	 */

	public BigDecimal getAccountKtTurnover(EntityManager em, String account, long iduser, long iddeal) {
		Query q = em.createNativeQuery(sqlUserDealKtTurnover);
		q.setParameter(1, iduser);
		q.setParameter(2, iduser);
		q.setParameter(3, iddeal);
		q.setParameter(4, iddeal);
		q.setParameter(5, account);
		BigDecimal saldo = (BigDecimal) q.getSingleResult();

		return saldo;
	}

	public void addAccounting(EntityManager em, String account1, String account2, long iduser, long iddeal,
			BigDecimal amount) {
		if (BigDecimal.ZERO.equals(amount)) {
			return;
		}
		Query q = em.createNativeQuery(sqlAddAccounting);
		q.setParameter(1, account1);
		q.setParameter(2, account2);
		q.setParameter(3, iduser);
		q.setParameter(4, iddeal);
		q.setParameter(5, amount);

		q.executeUpdate();
	}

	public void addAccounting(EntityManager em, String account1, String account2, long iduser, BigDecimal amount) {
		if (BigDecimal.ZERO.equals(amount)) {
			return;
		}
		Query q = em.createNativeQuery(sqlAddAccounting2);
		q.setParameter(1, account1);
		q.setParameter(2, account2);
		q.setParameter(3, iduser);
		q.setParameter(4, amount);

		q.executeUpdate();
	}

	public void addAccountingDeal(EntityManager em, String account1, String account2, long iddeal, BigDecimal amount) {
		if (BigDecimal.ZERO.equals(amount)) {
			return;
		}
		Query q = em.createNativeQuery(sqlAddAccounting3);
		q.setParameter(1, account1);
		q.setParameter(2, account2);
		q.setParameter(3, iddeal);
		q.setParameter(4, amount);

		q.executeUpdate();
	}

	public List<ReportCommission> getMonthSaldos(String accountCode) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		try {
			List<Object[]> r = em.createNativeQuery(sqlMonthSaldos).setParameter(1, accountCode).getResultList();
			List<ReportCommission> result = new ArrayList<ReportCommission>();
			int i = 1;
			for (Object[] row : r) {
				ReportCommission c = new ReportCommission();
				c.setId(i);
				c.setSum((BigDecimal) row[0]);
				c.setMonth((Integer) row[1]);
				c.setYear((Integer) row[2]);
				result.add(c);

				i++;
			}
			return result;
		} catch (NoResultException e) {
			return null;
		}
	}

	/**
	 * �������� ���� �������� � ����������
	 * 
	 * @throws Exception
	 */
	public void addOneAccounting(User u, String accDt, String accKt, BigDecimal sum) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		try {
			try {
				em.getTransaction().begin();
				addAccounting(em, accDt, accKt, u.getId(), sum);
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				throw e;
			}
		} finally {
			em.close();
		}
	}

	/**
	 * ��������������� �������� ��� ������
	 * 
	 * @param u
	 * @param sum
	 * @throws Exception
	 */
	public void reserveWithdraw(User u, BigDecimal sum) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		BigDecimal sumAvail = getAccountSaldo(em, AccountingController.A0002, u);
		if (sumAvail.doubleValue() < sum.doubleValue()) {
			throw new Exception("������������ �������");
		}
		addOneAccounting(u, AccountingController.A0002, AccountingController.A0008, sum);
	}

	/**
	 * ����������� ����� �������
	 * 
	 * @param u
	 * @param sum
	 * @throws Exception
	 */
	public void confirmWithdraw(User u, BigDecimal sum) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		BigDecimal sumAvail = getAccountSaldo(em, AccountingController.A0008, u);
		if (sumAvail.doubleValue() < sum.doubleValue()) {
			throw new Exception("������������ �������");
		}
		addOneAccounting(u, AccountingController.A0008, AccountingController.A0009, sum);
	}
}
