package org.insure.persistance;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.insure.model.User;

public class UserController {
	public static final String INIT = "INIT";
	public static final String BLOCKED = "BLOCKED";
	
	public List<User> getUsers() throws Exception {
		try {
			EntityManager em = EntityFacade.createEntityManager();

			Query q = em.createNamedQuery("User.findAll");
			List<User> result = q.getResultList();
			return result;
		} catch (NoResultException e) {
			return null;
		}
	}

	public User getUser(String name) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		try {
			User d = (User) em.createNamedQuery("User.findByName").setParameter("name", name).getSingleResult();
			return d;
		} catch (NoResultException e) {
			return null;
		}
	}

	public User getUser(long id) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		try {
			User d = (User) em.createNamedQuery("User.findById").setParameter("id", id).getSingleResult();
			return d;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public User getUserByEmail(String email) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		User u = null;
		try {
			u = (User) em.createNamedQuery("User.findByEmail").setParameter("email", email).getSingleResult();
			return u;
		} catch (NoResultException e) {
			return null;
		}
	}
	public User getUserByRegcode(String regcode) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		User u = null;
		try {
			u = (User) em.createNamedQuery("User.findByRegcode").setParameter("regcode", regcode).getSingleResult();
			return u;
		} catch (NoResultException e) {
			return null;
		}
	}

	public void updateUser(User u) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();

		em.merge(u);

		em.close();
	}

	public boolean userInit(User u, String name, String uuid, String p) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		if (u == null) {
			u = new User();
			u.setName(name);
			u.setStatus("INIT");
			u.setRegcode(uuid);
			u.setEmail(name);
			em.getTransaction().begin();
			u = applyPwd(u, p);
			em.persist(u);
			em.getTransaction().commit();
			return true;
		} else if ("INIT".equals(u.getStatus())) {
			u.setRegcode(uuid);
			em.getTransaction().begin();
			u = applyPwd(u, p);
			em.merge(u);
			em.getTransaction().commit();
			return true;
		}
		return false;
	}
	
	public boolean updatePwd(User u, String p) throws Exception {
		EntityManager em = EntityFacade.createEntityManager();
		if (u != null && u.getId() > 0) {
			em.getTransaction().begin();
			u = applyPwd(u, p);
			em.merge(u);
			em.getTransaction().commit();
			return true;
		} 
		return false;
	}
	
	public void changePwd(String name, String p1, String p2) throws Exception {
		User u = this.getUser(name);
		if (u == null) {
			throw new Exception("User not found");
		}
		if (!checkPwd(u, p1)) {
			throw new Exception("Password incorrect");
		}
		EntityManager em = EntityFacade.createEntityManager();
		try {
			try {
				em.getTransaction().begin();
				u = applyPwd(u, p2);
				u.setDigest("");
				em.merge(u);
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				throw e;
			}
		} finally {
			em.close();
		}
	}
	
	public boolean tryLoginUser(User u, String p) {
		try {
			if(!INIT.equals(u.getStatus()) && !BLOCKED.equals(u.getStatus()) && checkPwd(u, p)){
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean checkPwd(User u, String p) {
		try {
			String h = PasswordGenerator.getSha256(u.getSeed() + p);
			if(h.equals(u.getPassword())){
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}

	public boolean userCommit(User u, String code) throws Exception {
		if (u == null) {
			return false;
		}
		if(code.equals(u.getRegcode())){
			EntityManager em = EntityFacade.createEntityManager();
			u.setStatus("REG");
			em.getTransaction().begin();
			em.merge(u);
			em.getTransaction().commit();
		}
		u = getUser(u.getName());
		if ("INIT".equals(u.getStatus())) {
			return false;
		} else {
			return true;
		}
	}
	
	public User applyPwd(User u, String p) throws Exception{
		String seed = PasswordGenerator.getSeed();
		String hash = PasswordGenerator.getSha256(seed + p);
		
		u.setSeed(seed);
		u.setPassword(hash);
		
		return u;
	}}
