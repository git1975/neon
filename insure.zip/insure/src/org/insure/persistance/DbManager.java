package org.insure.persistance;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Manager of database singletone
 * 
 */
public class DbManager {
	private static final String sqlSetUserDigest = "UPDATE user SET digest=?,lasttime=now() WHERE name=?";
	private static final String sqlUpdateDigest = "UPDATE user SET lasttime=now() WHERE name=?";

	private static DbManager instance = null;

	private DbManager() {
	}

	public static DbManager getInstance() {
		if (instance == null) {
			instance = new DbManager();
		}

		return instance;
	}

	private static String getHostName() {
		InetAddress ip;
		String hostname;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();
			return hostname;
		} catch (UnknownHostException e) {
			e.printStackTrace();
			return null;
		}
	}

	public Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String pwd = "EODqol82884";
		String url = "jdbc:mysql://mysql111158-env-6697923.jelastic.regruhosting.ru/insure?useUnicode=yes&characterEncoding=UTF-8";

		String host = getHostName();
		if (host == null) {
			return null;
		}
		if (host.indexOf("regruhosting") >= 0) {
			return DriverManager.getConnection(url, "root", pwd);
		} else {
			return DriverManager.getConnection("jdbc:mysql://localhost:3306/insure", "root", "root");
		}
	}

	public void clearConnection(Connection con, PreparedStatement pstmt) {
		try {
			if (pstmt != null) {
				pstmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				con.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void closePreparedStatement(PreparedStatement pstmt) {
		try {
			if (pstmt != null) {
				pstmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void closeConnection(Connection con) {
		try {
			if (con != null) {
				con.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean setUserDigest(String name, String digest) throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sqlSetUserDigest);
			pstmt.setString(1, digest);
			pstmt.setString(2, name);
			pstmt.executeUpdate();
		} finally {
			close(con, pstmt);
		}
		return true;
	}

	public void updateDigest(String name) throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sqlUpdateDigest);
			pstmt.setString(1, name);
			pstmt.executeUpdate();
		} finally {
			close(con, pstmt);
		}
	}

	private static void close(Connection con, PreparedStatement pstmt, ResultSet rs) throws SQLException {
		if (rs != null) {
			rs.close();
		}
		if (pstmt != null) {
			pstmt.close();
		}
		if (con != null) {
			con.close();
		}
	}

	private static void close(Connection con, PreparedStatement pstmt) throws SQLException {
		if (pstmt != null) {
			pstmt.close();
		}
		if (con != null) {
			con.close();
		}
	}
}
