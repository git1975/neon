package org.insure.json.factory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.insure.json.wrapper.BalanceWrapper;
import org.insure.json.wrapper.ChngPwdWrapper;
import org.insure.json.wrapper.CloseDealWrapper;
import org.insure.json.wrapper.CoveringWrapper;
import org.insure.json.wrapper.DelClientWrapper;
import org.insure.json.wrapper.DelDealWrapper;
import org.insure.json.wrapper.DelUserWrapper;
import org.insure.json.wrapper.DeleteUserDealWrapper;
import org.insure.json.wrapper.DonateWrapper;
import org.insure.json.wrapper.GetClientWrapper;
import org.insure.json.wrapper.GetClientsWrapper;
import org.insure.json.wrapper.GetDealUsersWrapper;
import org.insure.json.wrapper.GetDealsWrapper;
import org.insure.json.wrapper.GetDictWrapper;
import org.insure.json.wrapper.GetDictionariesWrapper;
import org.insure.json.wrapper.GetSaldosWrapper;
import org.insure.json.wrapper.GetUserDealsWrapper;
import org.insure.json.wrapper.GetUsersWrapper;
import org.insure.json.wrapper.InvestDealWrapper;
import org.insure.json.wrapper.InvestUserDealWrapper;
import org.insure.json.wrapper.JsonWrapper;
import org.insure.json.wrapper.LoginWrapper;
import org.insure.json.wrapper.ReguserWrapper;
import org.insure.json.wrapper.ReportCommissionWrapper;
import org.insure.json.wrapper.ResetPasswordWrapper;
import org.insure.json.wrapper.ResuserWrapper;
import org.insure.json.wrapper.SendmsgWrapper;
import org.insure.json.wrapper.UpdateClientWrapper;
import org.insure.json.wrapper.UpdateDealWrapper;
import org.insure.json.wrapper.UpdateDictWrapper;
import org.insure.json.wrapper.UpdateOpWrapper;
import org.insure.json.wrapper.UpdateUserDealWrapper;
import org.insure.json.wrapper.UpdateUserWrapper;
import org.insure.json.wrapper.UserWrapper;
import org.insure.json.wrapper.ValidateUserWrapper;
import org.insure.json.wrapper.WithdrawConfWrapper;
import org.insure.json.wrapper.WithdrawWrapper;

import net.sf.json.JSONObject;

public class JsonFactory {
	private HttpServletResponse response;
	private static final JsonWrapper[] wrappers = new JsonWrapper[]{
			new LoginWrapper(), 
			new UserWrapper(), 
			new BalanceWrapper(), 
			new DonateWrapper(), 
			new ReguserWrapper(), 
			new CoveringWrapper(), 
			new GetDealsWrapper(), 
			new UpdateDealWrapper(), 
			new GetClientsWrapper(), 
			new UpdateClientWrapper(), 
			new GetUsersWrapper(), 
			new UpdateUserWrapper(), 
			new GetUserDealsWrapper(), 
			new UpdateUserDealWrapper(), 
			new DeleteUserDealWrapper(), 
			new GetClientWrapper(), 
			new DelUserWrapper(), 
			new DelDealWrapper(), 
			new DelClientWrapper(), 
			new ChngPwdWrapper(), 
			new InvestUserDealWrapper(), 
			new CloseDealWrapper(), 
			new GetDealUsersWrapper(), 
			new ResuserWrapper(), 
			new ResetPasswordWrapper(), 
			new GetDictionariesWrapper(), 
			new UpdateDictWrapper(), 
			new ReportCommissionWrapper(), 
			new WithdrawWrapper(), 
			new WithdrawConfWrapper(), 
			new InvestDealWrapper(), 
			new GetDictWrapper(),
			new ValidateUserWrapper(),
			new UpdateOpWrapper(),
			new GetSaldosWrapper(),
			new SendmsgWrapper()
		};

	public JsonFactory(HttpServletResponse response) {
		this.response = response;
	}
	
	public JsonWrapper getWrapper(String method) throws Exception {
		for (JsonWrapper item : wrappers) {
			if (item.getMethod().equals(method)) {
				return item;
			}
		}
		return null;
	}

	public String getJson(String method, Map<String, String> params) throws Exception {
		String json = null;
		JsonWrapper wrapper = getWrapper(method);
		json = (wrapper == null)?null:wrapper.doMethod(params);
		if(json == null){
			JSONObject obj = new JSONObject();
			obj.put("error", "Unknown method: " + method);
			json = obj.toString();
		}
		return json;
	}

	public boolean checkDigest(Map<String, String> params) {
		return true;
	}
}
