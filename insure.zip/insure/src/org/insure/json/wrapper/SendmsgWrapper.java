package org.insure.json.wrapper;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.email.SendMail;
import org.insure.model.Dictionary;
import org.insure.persistance.DictionaryController;

import net.sf.json.JSONObject;

public class SendmsgWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(SendmsgWrapper.class.getName());
	private static final String emailSupport = "emailSupport";

	@Override
	public String getMethod() {
		return "sendmsg";
	}

	@Override
	public boolean needDigest() {
		return false;
	}

	@Override
	public boolean isAdmin() {
		return false;
	}

	@Override
	public boolean isSelf() {
		return true;
	}

	@Override
	public String doMethod(Map<String, String> params) throws Exception {
		String json = _doMethod(params);

		return json;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		String cont = params.get("cont");
		String msg = params.get("msg");
		try {
			DictionaryController dc = new DictionaryController();
			Dictionary d = dc.getDictionary(emailSupport);
			String emails = null;
			if (d == null || "".equals(d.getValue())) {
				emails = "akokorin@gmail.com";
			} else {
				emails = d.getValue();
			}
			String[] e = emails.split(";");
			for (String email : e) {
				SendMail se = new SendMail();
				se.send(email, "��������� ��������� ������������ " + params.get("name"), "�������: " + cont + "; \r\n���������: " + msg);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("status", "1");
		return j.toString();
	}

}
