package org.insure.json.wrapper;

import java.math.BigDecimal;
import java.util.Map;

import org.insure.persistance.EntityFacade;

import net.sf.json.JSONObject;

public class GetSaldosWrapper extends JsonWrapper{
	@Override
	public String getMethod() {
		return "saldos";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return true;
	}	
	
	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		String user = params.get("user");
		EntityFacade ef = new EntityFacade();
		BigDecimal[] s = ef.getSaldos();
		
		JSONObject j = new JSONObject();
		j.put("name", user);
		j.put("s", s);
		return j.toString();
	}
}
