package org.insure.json.wrapper;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.email.SendMail;
import org.insure.model.User;
import org.insure.persistance.AccountingController;
import org.insure.persistance.DictionaryController;
import org.insure.persistance.UserController;

import net.sf.json.JSONObject;

public class WithdrawConfWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(WithdrawConfWrapper.class.getName());

	@Override
	public String getMethod() {
		return "withdrawc";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		try {
			if (!params.get("sum").matches("[0-9]{1,10}(\\.[0-9]*)?")) {
				throw new Exception("��������� �����");
			}
			Long id = Long.parseLong(params.get("iduser"));
			BigDecimal sum = getParamBigDecimal(params, "sum");
			if (sum.doubleValue() <= 0) {
				throw new Exception("��������� �����");
			}

			User u = null;
			UserController uc = new UserController();
			u = uc.getUser(id);
			if (u == null) {
				throw new Exception("User not found: " + id);
			}

			AccountingController ac = new AccountingController();
			ac.confirmWithdraw(u, sum);

			DictionaryController dc = new DictionaryController();
			String withdrawEmail = dc.getDictionary("withdrawEmail").getValue();
			if (withdrawEmail != null && !"".equals(withdrawEmail)) {
				SendMail email = new SendMail();
				String title = String.format("�������� %s(%s)(%s)", "�����. ������", params.get("name"), u.getName());
				String body = String.format("�������� %s(%s)(%s, %s, %s, %s). �����, ���: %s", "�����. ������",
						params.get("name"), u.getName(), u.getEmail(), u.getClient().getFioString(),
						u.getClient().getFullname(), sum);
				email.send(withdrawEmail, title, body);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("success", "1");
		return j.toString();
	}
}
