package org.insure.json.wrapper;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.email.SendMail;
import org.insure.model.User;
import org.insure.persistance.AccountingController;
import org.insure.persistance.DictionaryController;
import org.insure.persistance.UserController;

import net.sf.json.JSONObject;

public class DonateWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(DonateWrapper.class.getName());

	@Override
	public String getMethod() {
		return "donate";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return false;
	}

	@Override
	public boolean isSelf() {
		return true;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		if (!params.get("sum").matches("[0-9]{1,10}(\\.[0-9]*)?")) {
			throw new Exception("��������� �����");
		}
		String name = params.get("user");
		BigDecimal sum = getParamBigDecimal(params, "sum");
		try {
			User u = null;
			UserController uc = new UserController();
			u = uc.getUser(name);
			if (u == null) {
				throw new Exception("User not found: " + name);
			}
			AccountingController ac = new AccountingController();
			ac.addOneAccounting(u, AccountingController.A0001, AccountingController.A0002, sum);

			DictionaryController dc = new DictionaryController();
			String withdrawEmail = dc.getDictionary("withdrawEmail").getValue();
			if (withdrawEmail != null && !"".equals(withdrawEmail)) {
				SendMail email = new SendMail();
				String title = String.format("�������� %s(%s)(%s)", "���������� �������", params.get("name"), u.getName());
				String body = String.format("�������� %s(%s)(%s, %s, %s, %s). �����, ���: %s",
						"���������� �������", params.get("name"), u.getName(), u.getEmail(), u.getClient().getFioString(),
						u.getClient().getFullname(), sum);
				email.send(withdrawEmail, title, body);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("sum", sum);
		j.put("name", name);
		return j.toString();
	}
}
