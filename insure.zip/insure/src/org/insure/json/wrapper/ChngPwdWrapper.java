package org.insure.json.wrapper;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.persistance.UserController;

import net.sf.json.JSONObject;

public class ChngPwdWrapper extends JsonWrapper{
	private static Logger log = LogManager.getLogger(ChngPwdWrapper.class.getName());

	@Override
	public String getMethod() {
		return "chngpwd";
	}

	@Override
	public boolean needDigest() {
		return true;
	}
	
	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		try {
			//EntityFacade ef = new EntityFacade();
			UserController uc = new UserController();
			uc.changePwd(params.get("user"), params.get("p1"), params.get("p2"));
			//ef.changePwd(params.get("user"), params.get("p1"), params.get("p2"));				
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("success", "1");
		return j.toString();
	}

	@Override
	public boolean isAdmin() {
		return false;
	}

	@Override
	public boolean isSelf() {
		return true;
	}
}
