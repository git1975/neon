package org.insure.json.wrapper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.User;
import org.insure.persistance.DbManager;
import org.insure.persistance.PasswordGenerator;
import org.insure.persistance.UserController;
import org.insure.persistance.VerifyCaptcha;

import net.sf.json.JSONObject;

public class LoginWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(LoginWrapper.class.getName());

	private static final String USER_RESTORE_PWD = "��������� ������������! ��� ���������� ������������ ������!";

	private String createDigest() {
		try {
			// Initialize SecureRandom
			// This is a lengthy operation, to be done only upon
			// initialization of the application
			SecureRandom prng = SecureRandom.getInstance("SHA1PRNG");

			// generate a random number
			String randomNum = new Integer(prng.nextInt()).toString();

			// get its digest
			MessageDigest sha = MessageDigest.getInstance("SHA-1");
			byte[] result = sha.digest(randomNum.getBytes());

			// System.out.println("Random number: " + randomNum);
			// System.out.println("Message digest: " + hexEncode(result));

			return PasswordGenerator.hexEncode(result);
		} catch (NoSuchAlgorithmException ex) {
			System.err.println(ex);

			return null;
		}
	}

	@Override
	public String getMethod() {
		return "login";
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		String name = params.get("name");
		String p = params.get("password");
		String a = params.get("a");
		User u = null;
		try {
			if (!VerifyCaptcha.verify(params.get("rcptch"))) {
				throw new Exception(VerifyCaptcha.USER_ENTR_CAPTCHA);
			}
			
			UserController uc = new UserController();
			u = uc.getUser(name);
			if (u == null) {
				log.debug("Invalid name: " + name);
				return "{}";
			}			

			if (u.getSeed() == null || "".equals(u.getSeed())) {
				throw new Exception(USER_RESTORE_PWD);
			}
			if (!uc.tryLoginUser(u, p)) {
				log.debug("tryLoginUser failed: " + name);
				return "{}";
			}
			boolean isAdmin = (u.getAdmin() != null && u.getAdmin() == 1);
			if ("1".equals(a) && !isAdmin || !"1".equals(a) && isAdmin) {
				throw new Exception("-1");
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.debug("login failed: " + e.toString());
			log.error(e);
			throw e;
		}

		String digest = createDigest();
		DbManager.getInstance().setUserDigest(name, digest);
		JSONObject j = new JSONObject();
		j.put("digest", digest);
		j.put("name", u.getName());
		j.put("firstname", u.getFirstname());
		j.put("middlename", u.getMiddlename());
		j.put("lastname", u.getLastname());
		j.put("status", u.getStatus());
		// j.put("admin", u.getAdmin());
		return j.toString();
	}

	@Override
	public boolean needDigest() {
		return false;
	}

	@Override
	public boolean isAdmin() {
		return false;
	}

	@Override
	public boolean isSelf() {
		return true;
	}
}
