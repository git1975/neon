package org.insure.json.wrapper;

import java.util.List;
import java.util.Map;

import org.insure.model.ReportCommission;
import org.insure.persistance.AccountingController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ReportCommissionWrapper extends JsonWrapper{
	@Override
	public String getMethod() {
		return "repcomm";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}	
	
	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		AccountingController ac = new AccountingController();
		List<ReportCommission> r = ac.getMonthSaldos("A0007");
		
		GsonBuilder builder = new GsonBuilder();
		builder.excludeFieldsWithoutExposeAnnotation();
		Gson gson = builder.create();
		
		return gson.toJson(r);
	}
}
