package org.insure.json.wrapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Client;
import org.insure.persistance.EntityFacade;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GetClientsWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(GetClientsWrapper.class.getName());

	@Override
	public String getMethod() {
		return "getclients";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		List<Client> rows = null;
		try {
			EntityFacade ef = new EntityFacade();
			rows = ef.getClients(params.get("ctp"));
			// ��� ������ ��������� �����
			if ("A".equals(params.get("ctp"))) {
				rows.addAll(ef.getClients("U"));
			}
			for (Client c : rows) {
				if ("B".equals(c.getCtp())) {
					//�����
					double p = ef.getCptySumpremium(c.getId()).doubleValue();
					double l = ef.getCptySumloss(c.getId()).doubleValue();
					c.setSumpremium(new BigDecimal(p));
					c.setSumloss(new BigDecimal(l));
					c.setLossness((p == 0) ? new BigDecimal("0.00") : new BigDecimal(l / p));
				} else {
					//������
					double p = ef.getClientSumpremium(c.getId()).doubleValue();
					double l = ef.getClientSumloss(c.getId()).doubleValue();
					c.setRiskpast(ef.getClientRiskpast(c.getId()));
					c.setRiskrealize(ef.getClientRiskrealize(c.getId()));
					c.setSumpremium(new BigDecimal(p));
					c.setSumloss(new BigDecimal(l));
					c.setLossness((p == 0) ? new BigDecimal("0.00") : new BigDecimal(l / p));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		GsonBuilder builder = new GsonBuilder();
		builder.excludeFieldsWithoutExposeAnnotation();
		Gson gson = builder.setDateFormat("dd.MM.yyyy").create();

		return gson.toJson(rows);
	}
}
