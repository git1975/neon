package org.insure.json.wrapper;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Client;
import org.insure.persistance.EntityFacade;

import net.sf.json.JSONObject;

public class UpdateClientWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(UpdateClientWrapper.class.getName());

	@Override
	public String getMethod() {
		return "saveclient";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		try {
			long id = Long.parseLong(params.get("id"));
			Client c = null;
			EntityFacade ef = new EntityFacade();
			if (id != 0) {
				c = ef.getClient(id);
			} else {
				c = new Client();
			}
			c.setCtp(params.get("ctp"));
			c.setName("");
			c.setFullname(params.get("fullname"));
			c.setDtp(params.get("dtp"));
			c.setDul(params.get("dul"));
			c.setLastname(params.get("lastname"));
			c.setFirstname(params.get("firstname"));
			c.setMiddlename(params.get("middlename"));
			c.setSex(params.get("sex"));
			c.setLocation(params.get("location"));
			c.setBankinfo(params.get("bankinfo"));
			c.setPhone(params.get("phone"));
			c.setEmail(params.get("email"));
			c.setPosition(params.get("position"));
			c.setAddress1(params.get("address1"));
			c.setAddress2(params.get("address2"));
			c.setWorkname(params.get("workname"));
			c.setWorkposition(params.get("workposition"));
			c.setWorkaddress(params.get("workaddress"));
			c.setWorkphone(params.get("workphone"));
			c.setBankbic(params.get("bankbic"));
			c.setBankacc(params.get("bankacc"));
			c.setInn(params.get("inn"));
			c.setOgrn(params.get("ogrn"));
			c.setContactname(params.get("contactname"));
			c.setContactposition(params.get("contactposition"));
			c.setCreatedate(getParamDate(params, "createdate"));
			c.setDuldt(getParamDate(params, "duldt"));

			ef.updateClient(c);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("success", "1");
		return j.toString();
	}
}
