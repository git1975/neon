package org.insure.json.wrapper;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Dictionary;
import org.insure.persistance.DictionaryController;

import net.sf.json.JSONObject;

public class UpdateDictWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(UpdateDictWrapper.class.getName());

	@Override
	public String getMethod() {
		return "savedict";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		try {
			checkMandatory(params, "code", "���");
			checkMandatory(params, "value", "��������");

			DictionaryController c = new DictionaryController();
			long id = Long.parseLong(params.get("id"));			
			Dictionary d = null;
			if (id != 0) {
				d = c.getDictionary(id);
			} else {
				d = new Dictionary();
			}
			d.setCode(params.get("code"));
			d.setValue(params.get("value"));
			d.setDescription(params.get("description"));

			c.updateDictionary(d);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("success", "1");
		return j.toString();
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return true;
	}
}
