package org.insure.json.wrapper;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Client;
import org.insure.persistance.EntityFacade;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GetClientWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(GetClientWrapper.class.getName());

	@Override
	public String getMethod() {
		return "getclient";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return true;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		Client c = null;
		try {
			long id = Long.parseLong(params.get("idclient"));
			
			EntityFacade ef = new EntityFacade();
			c = ef.getClient(id);			
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		GsonBuilder builder = new GsonBuilder().setDateFormat("dd.MM.yyyy");
		builder.excludeFieldsWithoutExposeAnnotation();
		Gson gson = builder.setDateFormat("dd.MM.yyyy").create();
				
		return gson.toJson(c);
	}
}
