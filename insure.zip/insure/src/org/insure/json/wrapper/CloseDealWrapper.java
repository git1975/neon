package org.insure.json.wrapper;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Deal;
import org.insure.persistance.EntityFacade;

import net.sf.json.JSONObject;

public class CloseDealWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(CloseDealWrapper.class.getName());

	@Override
	public String getMethod() {
		return "closedeal";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}
	
	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		try {
			Long id = Long.parseLong(params.get("id"));
			Deal d = null;
			EntityFacade ef = new EntityFacade();
			d = ef.getDeal(id);
			if(d == null){
				throw new Exception("Deal not found: " + id);
			}
			
			d.setLoss(BigDecimal.valueOf(Double.valueOf(params.get("loss"))));
			//d.setOurprem(BigDecimal.valueOf(Double.valueOf(params.get("ourprem"))));
			ef.closeDeal(d);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("success", "1");
		return j.toString();
	}
}
