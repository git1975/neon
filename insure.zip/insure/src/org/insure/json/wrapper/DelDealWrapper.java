package org.insure.json.wrapper;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.persistance.EntityFacade;

import net.sf.json.JSONObject;

public class DelDealWrapper extends JsonWrapper{
	private static Logger log = LogManager.getLogger(DelDealWrapper.class.getName());

	@Override
	public String getMethod() {
		return "deldeal";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}
	
	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		long id = Long.parseLong(params.get("id"));
		try {
			EntityFacade ef = new EntityFacade();
			ef.deleteDeal(id);	
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("success", "1");
		return j.toString();
	}
}
