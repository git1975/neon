package org.insure.json.wrapper;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Operation;
import org.insure.model.User;
import org.insure.persistance.OperationController;
import org.insure.persistance.UserController;

import net.sf.json.JSONObject;

public class UpdateOpWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(UpdateOpWrapper.class.getName());

	@Override
	public String getMethod() {
		return "saveop";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		if (!params.get("sum").matches("[0-9]{1,10}(\\.[0-9]*)?")) {
			throw new Exception("��������� �����");
		}
		long id = 0;
		Operation o = null;
		try {
			checkMandatory(params, "sum", "�����");

			OperationController oc = new OperationController();
			UserController uc = new UserController();
			String name = params.get("name");
			User u = uc.getUser(name);
			
			o = new Operation();
			o.setUser(u);
			o.setCreatedate(new Date());
			o.setCost(new BigDecimal(params.get("sum")));
			o.setEmail(u.getEmail());
			o.setComment(u.getName() + ":" + params.get("sum"));
			o.setName(u.getName() + ":" + params.get("sum"));
			o.setStatus("INIT");
			o.setType(1);
			o.setLogin(name);

			id = oc.insertOperation(o);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("id", id);
		j.put("sum", o.getCost());
		j.put("email", o.getEmail());
		j.put("name", o.getName());
		JSONObject obj = new JSONObject();
		obj.put("op", j);
		return obj.toString();
	}

	@Override
	public boolean isAdmin() {
		return false;
	}

	@Override
	public boolean isSelf() {
		return true;
	}
}