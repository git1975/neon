package org.insure.json.wrapper;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.persistance.AccountingController;
import org.insure.persistance.EntityFacade;

import net.sf.json.JSONObject;

public class InvestUserDealWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(InvestUserDealWrapper.class.getName());

	@Override
	public String getMethod() {
		return "usrdealinv";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}
	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		BigDecimal saldo = new BigDecimal("0.00");
		try {
			long iddeal = Long.parseLong(params.get("iddeal"));
			long iduser = Long.parseLong(params.get("iduser"));
			BigDecimal amount = new BigDecimal(params.get("amount"));
			
			EntityFacade ef = new EntityFacade();
			BigDecimal s1 = ef.getAccountSaldo(AccountingController.A0002, ef.getUser(iduser));
			if(s1.compareTo(amount) < 0){
				throw new Exception("������������ �������");
			}
			ef.addUserDealSaldo(iduser, iddeal, amount);
			saldo = ef.getUserDealSaldo(iduser, iddeal);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("saldo", saldo);
		return j.toString();
	}

}
