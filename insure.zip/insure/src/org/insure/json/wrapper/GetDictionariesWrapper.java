package org.insure.json.wrapper;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Dictionary;
import org.insure.persistance.DictionaryController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GetDictionariesWrapper extends JsonWrapper{
	private static Logger log = LogManager.getLogger(GetDictionariesWrapper.class.getName());

	@Override
	public String getMethod() {
		return "dictionaries";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}
	
	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		List<Dictionary> rows = null;
		try {
			DictionaryController c = new DictionaryController();
			rows = c.getDictionaries();
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}
		
		GsonBuilder builder = new GsonBuilder();
		builder.excludeFieldsWithoutExposeAnnotation();
		Gson gson = builder.create();
		
		return gson.toJson(rows);
	}
}
