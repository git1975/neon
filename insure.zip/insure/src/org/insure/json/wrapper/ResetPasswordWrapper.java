package org.insure.json.wrapper;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.email.SendMail;
import org.insure.model.User;
import org.insure.persistance.PasswordGenerator;
import org.insure.persistance.UserController;

import net.sf.json.JSONObject;

public class ResetPasswordWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(ResetPasswordWrapper.class.getName());

	@Override
	public String getMethod() {
		return "resetpassword";
	}

	@Override
	public boolean needDigest() {
		return false;
	}

	@Override
	public boolean isAdmin() {
		return false;
	}

	@Override
	public boolean isSelf() {
		return true;
	}

	@Override
	public String doMethod(Map<String, String> params) throws Exception {
		String json = _doMethod(params);

		return json;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		String code = params.get("code");
		try {
			UserController uc = new UserController();
			User u = uc.getUserByRegcode(code);
			// �������� ������������
			if (u == null) {
				throw new Exception("Incorrect reset code");
			}
			// Send confirm reset email
			String p = PasswordGenerator.get();
			SendMail email = new SendMail();
			email.send(u.getEmail(), "����� ������ � investor.insurion.org", "��� ����� � investor.insurion.org: " + u.getName() + "\r\n" + "��� ����� ������: " + p);

			log.info("New password sent to " + u.getEmail());
			uc.updatePwd(u, p);
			JSONObject o = new JSONObject();
			o.put("status", "��� �� ����� ��������� ����� ������ � Insurion");
			return o.toString();
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw e;
		}
	}

}
