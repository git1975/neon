package org.insure.json.wrapper;

import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.email.SendMail;
import org.insure.model.User;
import org.insure.persistance.EntityFacade;
import org.insure.persistance.VerifyCaptcha;

import net.sf.json.JSONObject;

public class ResuserWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(ResuserWrapper.class.getName());

	@Override
	public String getMethod() {
		return "resuser";
	}

	@Override
	public boolean needDigest() {
		return false;
	}

	@Override
	public boolean isAdmin() {
		return false;
	}

	@Override
	public boolean isSelf() {
		return true;
	}

	@Override
	public String doMethod(Map<String, String> params) throws Exception {
		String json = _doMethod(params);

		return json;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		String name = params.get("name");
		try {
			if(!VerifyCaptcha.verify(params.get("rcptch"))){
				throw new Exception(VerifyCaptcha.USER_ENTR_CAPTCHA);
			}
			EntityFacade ef = new EntityFacade();
			User u = ef.getUser(name);
			if (u == null) {
				u = ef.getUserByEmail(name);
			}
			// �������� ������������
			if (u == null) {
				throw new Exception("User doesn't exists");
			}
			// Send confirm reset email
			String code = UUID.randomUUID().toString().replace("-", "");
			SendMail email = new SendMail();
			email.send(u.getEmail(), "����� ������ � investor.insurion.org", "��� ��������� ������ ������ � investor.insurion.org ��������� �� ���� ������: " + SendMail.getSiteUrl(params)
					+ "/json?method=resetpassword&code=" + code);

			log.info("Reset password confirmation sent to " + u.getEmail());
			u.setRegcode(code);
			ef.updateUser(u);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("status", "1");
		return j.toString();
	}

}
