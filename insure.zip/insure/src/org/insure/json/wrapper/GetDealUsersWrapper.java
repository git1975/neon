package org.insure.json.wrapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Userdeal;
import org.insure.persistance.EntityFacade;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GetDealUsersWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(GetDealUsersWrapper.class.getName());

	@Override
	public String getMethod() {
		return "getdealusers";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		long iddeal = Long.parseLong(params.get("iddeal"));
		List<Userdeal> rows = null;
		try {
			EntityFacade ef = new EntityFacade();
			rows = ef.getGetUserDealsByDeal(ef.getDeal(iddeal));
			for (Userdeal row : rows) {
				BigDecimal saldo = ef.getUserDealSaldo(row.getUser().getId(), row.getDeal().getId());
				BigDecimal profit = ef.getUserDealProfit(row.getUser().getId(), row.getDeal().getId());
				row.getUser().setInvest(saldo);
				row.getUser().setProfit(profit);
				row.getUser().setPercent(new BigDecimal(saldo.doubleValue()*100/row.getDeal().getSum().doubleValue()));
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}
		
		GsonBuilder builder = new GsonBuilder();
		Gson gson = builder.excludeFieldsWithoutExposeAnnotation().setDateFormat("dd.MM.yyyy").create();
		
		return gson.toJson(rows);
	}
}