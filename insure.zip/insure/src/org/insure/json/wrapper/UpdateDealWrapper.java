package org.insure.json.wrapper;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Deal;
import org.insure.persistance.EntityFacade;

import net.sf.json.JSONObject;

public class UpdateDealWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(UpdateDealWrapper.class.getName());

	@Override
	public String getMethod() {
		return "savedeal";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}	
	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		try {
			Long id = Long.parseLong(params.get("id"));
			Deal d = null;
			EntityFacade ef = new EntityFacade();
			if (id != 0) {
				d = ef.getDeal(id);
			} else {
				d = new Deal();
			}
			
			d.setClient(ef.getClient(Long.parseLong(params.get("idclient"))));
			d.setCpty(ef.getClient(Long.parseLong(params.get("idcpty"))));
			d.setPremium(BigDecimal.valueOf(Double.valueOf(params.get("premium"))));
			d.setSum(BigDecimal.valueOf(Double.valueOf(params.get("sum"))));
			d.setObjectinsurance(params.get("objectinsurance"));
			d.setCreatedate(getParamDate(params, "createdate"));
			d.setBegindate(getParamDate(params, "begindate"));
			d.setEnddate(getParamDate(params, "enddate"));
			if(d.getEnddate() == null || d.getBegindate() == null){
				d.setTerm(0);
			} else {
				long diff = d.getEnddate().getTime() - d.getBegindate().getTime();
				d.setTerm(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
			}
			//d.setTerm(Integer.parseInt(params.get("term")));
			d.setStatus(ef.getDealstatus(getParamInt(params, "status")));
			
			ef.updateDeal(d);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("success", "1");
		return j.toString();
	}

}
