package org.insure.json.wrapper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Client;
import org.insure.model.User;
import org.insure.persistance.EntityFacade;
import org.insure.persistance.PasswordGenerator;

import net.sf.json.JSONObject;

public class UpdateUserWrapper extends JsonWrapper {
	private static final SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
	private static Logger log = LogManager.getLogger(UpdateUserWrapper.class.getName());

	@Override
	public String getMethod() {
		return "saveuser";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		try {
			checkMandatory(params, "username", "�����");
			checkMandatory(params, "email", "E-mail");
			
			long iduser = Long.parseLong(params.get("iduser"));
			org.insure.model.User row = null;
			Client c = null;
			EntityFacade ef = new EntityFacade();
			if (iduser != 0) {
				row = ef.getUser(iduser);
				row.setName(params.get("username"));
				row.setEmail(params.get("email"));
				ef.checkUserClient(row);
			} else {
				row = new User();
				row.setClient(new Client());
				row.setName(params.get("username"));
				row.setEmail(params.get("email"));
			}
			if(params.get("status") != null && !"".equals(params.get("status"))){
				row.setStatus(params.get("status"));
			}
			c = row.getClient();
			c.setCtp("I");
			c.setName(params.get("username"));
			c.setFullname(params.get("fullname"));
			c.setDtp(params.get("dtp"));
			c.setDul(params.get("dul"));
			c.setDulkem(params.get("dulkem"));
			Date duldt = null;
			try{
				duldt = sdf.parse(params.get("duldt"));
			}catch(Exception e){
				e.printStackTrace();
				duldt = null;
			}
			c.setDuldt(duldt);
			c.setLastname(params.get("lastname"));
			c.setFirstname(params.get("firstname"));
			c.setMiddlename(params.get("middlename"));
			c.setSex(params.get("sex"));
			c.setLocation(params.get("location"));
			c.setBankinfo(params.get("bankinfo"));
			c.setPhone(params.get("phone"));
			c.setEmail(params.get("email"));
			c.setPosition(params.get("position"));
			c.setCity(params.get("city"));
			c.setStreet(params.get("street"));
			c.setDom(params.get("dom"));
			c.setFlat(params.get("flat"));
			c.setBankbic(params.get("bankbic"));
			c.setBankacc(params.get("bankacc"));

			ef.updateUser(row);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		JSONObject j = new JSONObject();
		j.put("success", "1");
		return j.toString();
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return true;
	}
}
