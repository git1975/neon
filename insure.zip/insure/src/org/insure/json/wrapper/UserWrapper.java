package org.insure.json.wrapper;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.User;
import org.insure.persistance.EntityFacade;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class UserWrapper extends JsonWrapper{
	private static Logger log = LogManager.getLogger(UserWrapper.class.getName());

	@Override
	public String getMethod() {
		return "getuser";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return true;
	}
	
	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		User u = null;
		try {
			EntityFacade ef = new EntityFacade();
			u = ef.getUser(params.get("name"));	
			ef.checkUserClient(u);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}

		GsonBuilder builder = new GsonBuilder();
		builder.excludeFieldsWithoutExposeAnnotation();
		Gson gson = builder.setDateFormat("dd.MM.yyyy").create();
		
		return gson.toJson(u);
	}
}
