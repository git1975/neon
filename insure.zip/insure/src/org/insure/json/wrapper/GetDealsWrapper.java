package org.insure.json.wrapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.insure.model.Client;
import org.insure.model.Deal;
import org.insure.persistance.EntityFacade;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GetDealsWrapper extends JsonWrapper {
	private static Logger log = LogManager.getLogger(GetDealsWrapper.class.getName());

	@Override
	public String getMethod() {
		return "getdeals";
	}

	@Override
	public boolean needDigest() {
		return true;
	}

	@Override
	public boolean isAdmin() {
		return true;
	}

	@Override
	public boolean isSelf() {
		return false;
	}

	@Override
	protected String _doMethod(Map<String, String> params) throws Exception {
		List<Deal> rows = null;
		try {
			EntityFacade ef = new EntityFacade();
			rows = ef.getDeals();
			for(Deal row: rows){
				BigDecimal s = ef.getUserDealSaldo(0, row.getId());
				row.setSaldo(s);

				Client c = row.getClient();
				if("A".equals(c.getCtp())){
					c.setFullname(c.getLastname() + " " + c.getFirstname() + " " + c.getMiddlename());
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(getMethod() + ": " + e.toString());
			log.error(e);
			throw e;
		}
	
		GsonBuilder builder = new GsonBuilder().setDateFormat("dd.MM.yyyy");
		//builder.excludeFieldsWithoutExposeAnnotation();
		Gson gson = builder.setDateFormat("dd.MM.yyyy").create();
		
		return gson.toJson(rows);
	}
}
