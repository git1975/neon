-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: insure
-- ------------------------------------------------------
-- Server version	5.6.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(20) NOT NULL,
  `isactive` int(11) NOT NULL COMMENT 'счет активный(1) или пассивный(-1)',
  `idparent` int(11) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ACCOUNT_NUMBER` (`number`),
  KEY `ACCOUNT_PARENT_idx` (`idparent`),
  CONSTRAINT `ACCOUNT_PARENT` FOREIGN KEY (`idparent`) REFERENCES `account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'A0002',1,NULL,'Поступившие средства инвестора'),(2,'A0003',1,NULL,'Счет инвестиций'),(3,'A0001',-1,NULL,'Пассивный счет карты'),(4,'A0004',1,NULL,'Счет дохода от инвестиции'),(5,'A0005',-1,NULL,'Счет сделки'),(6,'A0006',1,NULL,'Счет убытков по риску'),(7,'A0007',1,NULL,'Счет комиссии Insurion по риску');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting`
--

DROP TABLE IF EXISTS `accounting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddtaccount` int(11) NOT NULL,
  `idktaccount` int(11) NOT NULL,
  `amount` decimal(10,4) NOT NULL,
  `operdate` date NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `desc` varchar(100) DEFAULT NULL,
  `iddeal` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ACCOUNTING_USER_idx` (`iduser`),
  KEY `ACCOUNTING_DT_idx` (`dt`),
  KEY `ACCOUNTING_DTACC_idx` (`iddtaccount`),
  KEY `ACCOUNTING_KTACC_idx` (`idktaccount`),
  KEY `ACCOUNTING_DEAL_idx` (`iddeal`),
  CONSTRAINT `ACCOUNTING_DEAL` FOREIGN KEY (`iddeal`) REFERENCES `deal` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ACCOUNTING_DTACC` FOREIGN KEY (`iddtaccount`) REFERENCES `account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ACCOUNTING_KTACC` FOREIGN KEY (`idktaccount`) REFERENCES `account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ACCOUNTING_USER` FOREIGN KEY (`iduser`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting`
--

LOCK TABLES `accounting` WRITE;
/*!40000 ALTER TABLE `accounting` DISABLE KEYS */;
INSERT INTO `accounting` VALUES (183,3,1,5000.0000,'2016-09-07',31,'denzorin1@gmail.com','2016-09-07 10:22:18',NULL,NULL),(184,3,1,5000.0000,'2016-09-07',28,'petrov@gmail.com','2016-09-07 10:22:37',NULL,NULL),(185,1,2,5000.0000,'2016-09-07',28,NULL,'2016-09-07 10:22:52',NULL,29),(186,1,2,2500.0000,'2016-09-07',31,NULL,'2016-09-07 10:23:05',NULL,29),(187,5,4,-255.2778,'2016-09-07',31,NULL,'2016-09-07 10:23:16',NULL,29),(188,4,1,-255.2778,'2016-09-07',31,NULL,'2016-09-07 10:23:16',NULL,29),(189,2,1,2500.0000,'2016-09-07',31,NULL,'2016-09-07 10:23:16',NULL,29),(190,5,6,10000.0000,'2016-09-07',31,NULL,'2016-09-07 10:23:17',NULL,29),(191,5,7,90.0000,'2016-09-07',31,NULL,'2016-09-07 10:23:17',NULL,29),(192,5,4,-510.5556,'2016-09-07',28,NULL,'2016-09-07 10:23:17',NULL,29),(193,4,1,-510.5556,'2016-09-07',28,NULL,'2016-09-07 10:23:17',NULL,29),(194,2,1,5000.0000,'2016-09-07',28,NULL,'2016-09-07 10:23:17',NULL,29),(195,5,6,10000.0000,'2016-09-07',28,NULL,'2016-09-07 10:23:17',NULL,29),(196,5,7,90.0000,'2016-09-07',28,NULL,'2016-09-07 10:23:17',NULL,29),(197,3,1,100.0000,'2016-09-09',31,'denzorin1@gmail.com','2016-09-09 22:17:36',NULL,NULL),(198,3,1,100.0000,'2016-09-09',32,'denzorin@yahoo.com','2016-09-09 23:14:12',NULL,NULL);
/*!40000 ALTER TABLE `accounting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `fullname` varchar(250) DEFAULT NULL,
  `ctp` char(1) NOT NULL,
  `dtp` char(1) DEFAULT NULL,
  `dul` varchar(50) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `middlename` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL COMMENT 'пол',
  `location` varchar(250) DEFAULT NULL COMMENT 'прописка/адрес',
  `bankinfo` varchar(250) DEFAULT NULL COMMENT 'Реквизиты банковского счета',
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата создания',
  `phone` varchar(50) DEFAULT NULL COMMENT 'Телефон',
  `email` varchar(100) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL COMMENT 'Должность',
  `dulkem` varchar(100) DEFAULT NULL,
  `duldt` date DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `dom` varchar(10) DEFAULT NULL,
  `flat` varchar(10) DEFAULT NULL,
  `bankacc` varchar(20) DEFAULT NULL,
  `bankbic` varchar(9) DEFAULT NULL,
  `workname` varchar(150) DEFAULT NULL,
  `workposition` varchar(100) DEFAULT NULL,
  `workaddress` varchar(100) DEFAULT NULL,
  `workphone` varchar(50) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `inn` varchar(15) DEFAULT NULL,
  `ogrn` varchar(13) DEFAULT NULL,
  `contactname` varchar(100) DEFAULT NULL,
  `contactposition` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (23,'petrov@gmail.com',NULL,'I','A','','Петр','Петрович','Петров','M',NULL,NULL,'2016-08-07 00:00:00','3333333333','petrov@gmail.com',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'admin',NULL,'I',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2016-08-07 23:49:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'a123','ффф 123','I','A','','ы','в','ф433','M','','','2016-08-08 22:53:43','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,'denzorin112@gmail.com',NULL,'I','','','','','','',NULL,NULL,'2016-08-11 21:44:01','','',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,'',NULL,'A','A','1234 5678','Иван','Иванович','Иванов','M',NULL,NULL,'2016-10-14 00:00:00','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,'','ИП Ромашка','B',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2016-08-12 00:00:00','77777','88888',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'66666666666666666666','555555555',NULL,NULL,NULL,NULL,'3','4','111111111111111','2222222222222','99999','00000'),(32,'denzorin1@gmail.com',NULL,'I','A','1143321412','Денис','Валерьевич','Зорин','M',NULL,NULL,'2016-08-12 20:41:03','9161234567','denzorin1@gmail.com',NULL,'ОВД Лефортово','2004-02-29','Москва','10-я Соколиной горы','12','20','82222222222222222222','722222222',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,'',NULL,'U','A','111133333','Семен','Петрович','Петров','M',NULL,NULL,'2016-08-28 00:00:00','','',NULL,NULL,'2016-08-28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(35,'','ООО Фотобанк','U',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2220-01-01 00:00:00','77777','88888',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'66666666666666666666','555555555',NULL,NULL,NULL,NULL,'3','4','111111111111111','2222222222222',NULL,NULL),(36,'denzorin@yahoo.com',NULL,'I','','','','','','',NULL,NULL,'2016-09-09 00:00:00','','',NULL,'','2016-09-09','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deal`
--

DROP TABLE IF EXISTS `deal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idclient` int(11) NOT NULL,
  `idcpty` int(11) NOT NULL,
  `premium` decimal(10,2) NOT NULL,
  `sum` decimal(10,2) NOT NULL,
  `term` int(11) NOT NULL,
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `begindate` date DEFAULT NULL,
  `enddate` date DEFAULT NULL,
  `objectinsurance` varchar(100) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `loss` decimal(10,2) DEFAULT NULL,
  `ourprem` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `DEALCLIENT_FK_idx` (`idclient`),
  KEY `DEALCPTY_FK_idx` (`idcpty`),
  KEY `DEALSTAUS_FK_idx` (`status`),
  CONSTRAINT `DEALCLIENT_FK` FOREIGN KEY (`idclient`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DEALCPTY_FK` FOREIGN KEY (`idcpty`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DEALSTATUS_FK` FOREIGN KEY (`status`) REFERENCES `dealstatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deal`
--

LOCK TABLES `deal` WRITE;
/*!40000 ALTER TABLE `deal` DISABLE KEYS */;
INSERT INTO `deal` VALUES (29,30,31,900.00,90000.00,6,'2016-09-04 00:00:00','2016-12-31','2017-01-05','Объектив Nikon 1575',3,10000.00,90.00),(31,30,31,0.00,0.00,0,'2016-09-11 00:00:00',NULL,NULL,'',1,NULL,NULL);
/*!40000 ALTER TABLE `deal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dealstatus`
--

DROP TABLE IF EXISTS `dealstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dealstatus` (
  `id` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dealstatus`
--

LOCK TABLES `dealstatus` WRITE;
/*!40000 ALTER TABLE `dealstatus` DISABLE KEYS */;
INSERT INTO `dealstatus` VALUES (1,'EDIT','Редактируется'),(2,'INVEST','Инвестируется'),(3,'CLOSE','Закрыт'),(4,'CANCEL','Отменен');
/*!40000 ALTER TABLE `dealstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `middlename` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `digest` varchar(100) DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `regcode` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `admin` int(1) DEFAULT NULL,
  `idclient` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  KEY `USERSTATUS_FK_idx` (`status`),
  KEY `USERCLIENT_FK_idx` (`idclient`),
  CONSTRAINT `USERCLIENT_FK` FOREIGN KEY (`idclient`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `USERSTATUS_FK` FOREIGN KEY (`status`) REFERENCES `userstatus` (`code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'a123','a','Артем12','','','9b2767b685ee86e45118cd4ecfa6c9e1634d01ad','2016-07-28 18:33:55',NULL,'INVEST',NULL,25),(19,'admin','1','Админ','','','ef8600ce6ce4da1d6adc912627f321207f6683e2','2016-09-11 21:23:37',NULL,'INVEST',1,24),(23,'denzorin112@gmail.com','1','','','','d808e41b51fe5c91d02278bb18b157f346f4dd94','2016-08-01 20:36:19','38a57a2ded844511a41a1a88ea4f3448','INVEST',NULL,28),(28,'petrov@gmail.com','1','','','qq23','03c93b029e45196fd107ccb1a45a98b091dbc096','2016-09-09 20:10:24','1dc2dec0cb134f829913dded752984a6','REG',NULL,23),(30,'admin@qq.ru','55471014',NULL,NULL,NULL,NULL,'2016-08-12 20:32:49','a8e17ea6890742309d4c8c5c17c9ffa1','INIT',NULL,NULL),(31,'denzorin1@gmail.com','1',NULL,NULL,NULL,'4a470fe570aef1d3364e877ae8ca1940ed99a31f','2016-09-11 21:21:54','eaf06075c8524abca46320002446e38d','INVEST',NULL,32),(32,'denzorin@yahoo.com','1',NULL,NULL,NULL,'07f3130f04c9f30ef0e6e6da20d3454a705e4831','2016-09-09 23:24:14','33a0cc48b61e4e6eb73c49f510c335e2','INVEST',NULL,36);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdeals`
--

DROP TABLE IF EXISTS `userdeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userdeals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `iddeal` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `USERDEALS_UNX` (`iduser`,`iddeal`),
  KEY `FK_USERDEALS_USER_idx` (`iduser`),
  KEY `FK_USERDEALS_DEAL_idx` (`iddeal`),
  CONSTRAINT `FK_USERDEALS_DEAL` FOREIGN KEY (`iddeal`) REFERENCES `deal` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USERDEALS_USER` FOREIGN KEY (`iduser`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdeals`
--

LOCK TABLES `userdeals` WRITE;
/*!40000 ALTER TABLE `userdeals` DISABLE KEYS */;
INSERT INTO `userdeals` VALUES (57,28,29),(56,31,29);
/*!40000 ALTER TABLE `userdeals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userstatus`
--

DROP TABLE IF EXISTS `userstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_UNIQUE` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userstatus`
--

LOCK TABLES `userstatus` WRITE;
/*!40000 ALTER TABLE `userstatus` DISABLE KEYS */;
INSERT INTO `userstatus` VALUES (1,'INIT','Неподтветжденный'),(2,'REG','Зарегистрирован'),(3,'INVEST','Проинвестировавший'),(4,'BLOCKED','Заблокирован');
/*!40000 ALTER TABLE `userstatus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-11 23:59:16
