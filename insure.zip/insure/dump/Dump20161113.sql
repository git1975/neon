-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: insure
-- ------------------------------------------------------
-- Server version	5.6.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(20) NOT NULL,
  `isactive` int(11) NOT NULL COMMENT 'счет активный(1) или пассивный(-1)',
  `idparent` int(11) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ACCOUNT_NUMBER` (`number`),
  KEY `ACCOUNT_PARENT_idx` (`idparent`),
  CONSTRAINT `ACCOUNT_PARENT` FOREIGN KEY (`idparent`) REFERENCES `account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'A0002',1,NULL,'Поступившие средства инвестора'),(2,'A0003',1,NULL,'Счет инвестиций'),(3,'A0001',-1,NULL,'Пассивный счет карты'),(4,'A0004',1,NULL,'Счет дохода от инвестиции'),(5,'A0005',-1,NULL,'Счет сделки'),(6,'A0006',1,NULL,'Счет убытков по риску'),(7,'A0007',1,NULL,'Счет комиссии Insurion по риску'),(8,'A0008',1,NULL,'Счет резерва на вывод'),(9,'A0009',-1,NULL,'Вывенные средства');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting`
--

DROP TABLE IF EXISTS `accounting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddtaccount` int(11) NOT NULL,
  `idktaccount` int(11) NOT NULL,
  `amount` decimal(10,4) NOT NULL,
  `operdate` date NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `desc` varchar(100) DEFAULT NULL,
  `iddeal` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ACCOUNTING_USER_idx` (`iduser`),
  KEY `ACCOUNTING_DT_idx` (`dt`),
  KEY `ACCOUNTING_DTACC_idx` (`iddtaccount`),
  KEY `ACCOUNTING_KTACC_idx` (`idktaccount`),
  KEY `ACCOUNTING_DEAL_idx` (`iddeal`),
  CONSTRAINT `ACCOUNTING_DEAL` FOREIGN KEY (`iddeal`) REFERENCES `deal` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ACCOUNTING_DTACC` FOREIGN KEY (`iddtaccount`) REFERENCES `account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ACCOUNTING_KTACC` FOREIGN KEY (`idktaccount`) REFERENCES `account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ACCOUNTING_USER` FOREIGN KEY (`iduser`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=260 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting`
--

LOCK TABLES `accounting` WRITE;
/*!40000 ALTER TABLE `accounting` DISABLE KEYS */;
INSERT INTO `accounting` VALUES (225,3,1,5000.0000,'2016-10-08',31,NULL,'2016-10-08 22:45:37',NULL,NULL),(226,1,2,1000.0000,'2016-10-08',31,NULL,'2016-10-08 23:49:26',NULL,29),(227,5,4,9.0000,'2016-10-08',31,NULL,'2016-10-08 23:50:19',NULL,29),(228,4,1,9.0000,'2016-10-08',31,NULL,'2016-10-08 23:50:19',NULL,29),(229,2,1,1000.0000,'2016-10-08',31,NULL,'2016-10-08 23:50:19',NULL,29),(230,5,6,0.0000,'2016-10-08',31,NULL,'2016-10-08 23:50:19',NULL,29),(231,5,7,90.0000,'2016-10-08',31,NULL,'2016-10-08 23:50:19',NULL,29),(232,1,2,1000.0000,'2016-10-08',31,NULL,'2016-10-08 23:51:45',NULL,33),(233,5,4,15.0000,'2016-10-08',31,NULL,'2016-10-08 23:52:22',NULL,33),(234,4,1,15.0000,'2016-10-08',31,NULL,'2016-10-08 23:52:22',NULL,33),(235,2,1,1000.0000,'2016-10-08',31,NULL,'2016-10-08 23:52:22',NULL,33),(236,5,6,0.0000,'2016-10-08',31,NULL,'2016-10-08 23:52:22',NULL,33),(237,5,7,100.0000,'2016-10-08',31,NULL,'2016-10-08 23:52:22',NULL,33),(239,5,7,100.0000,'2016-10-09',NULL,NULL,'2016-10-09 17:08:51',NULL,31),(240,1,8,1.0000,'2016-10-09',31,NULL,'2016-10-09 17:21:59',NULL,NULL),(241,5,7,100.0000,'2016-10-09',NULL,NULL,'2016-10-09 20:55:36',NULL,33),(242,5,4,15.0000,'2016-10-09',31,NULL,'2016-10-09 20:55:41',NULL,33),(243,4,1,15.0000,'2016-10-09',31,NULL,'2016-10-09 20:55:41',NULL,33),(244,2,1,1000.0000,'2016-10-09',31,NULL,'2016-10-09 20:55:41',NULL,33),(245,5,6,0.0000,'2016-10-09',31,NULL,'2016-10-09 20:55:41',NULL,33),(246,5,7,100.0000,'2016-10-09',31,NULL,'2016-10-09 20:55:41',NULL,33),(247,5,7,100.0000,'2016-10-09',NULL,NULL,'2016-10-09 20:56:17',NULL,33),(248,5,4,15.0000,'2016-10-09',31,NULL,'2016-10-09 20:56:27',NULL,33),(249,4,1,15.0000,'2016-10-09',31,NULL,'2016-10-09 20:56:27',NULL,33),(250,2,1,1000.0000,'2016-10-09',31,NULL,'2016-10-09 20:56:27',NULL,33),(251,5,6,0.0000,'2016-10-09',31,NULL,'2016-10-09 20:56:27',NULL,33),(252,5,7,100.0000,'2016-10-09',31,NULL,'2016-10-09 20:56:27',NULL,33),(253,5,7,50.0000,'2016-10-09',NULL,NULL,'2016-10-09 21:51:11',NULL,36),(254,5,7,100.0000,'2016-10-10',NULL,NULL,'2016-10-10 22:45:35',NULL,33),(255,5,4,15.0000,'2016-10-10',31,NULL,'2016-10-10 22:46:04',NULL,33),(256,4,1,15.0000,'2016-10-10',31,NULL,'2016-10-10 22:46:04',NULL,33),(257,2,1,1000.0000,'2016-10-10',31,NULL,'2016-10-10 22:46:04',NULL,33),(258,5,6,0.0000,'2016-10-10',31,NULL,'2016-10-10 22:46:04',NULL,33),(259,8,9,1.0000,'2016-10-15',31,NULL,'2016-10-15 14:28:42',NULL,NULL);
/*!40000 ALTER TABLE `accounting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `fullname` varchar(250) DEFAULT NULL,
  `ctp` char(1) NOT NULL,
  `dtp` char(1) DEFAULT NULL,
  `dul` varchar(50) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `middlename` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL COMMENT 'пол',
  `location` varchar(250) DEFAULT NULL COMMENT 'прописка/адрес',
  `bankinfo` varchar(250) DEFAULT NULL COMMENT 'Реквизиты банковского счета',
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата создания',
  `phone` varchar(50) DEFAULT NULL COMMENT 'Телефон',
  `email` varchar(100) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL COMMENT 'Должность',
  `dulkem` varchar(100) DEFAULT NULL,
  `duldt` date DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `dom` varchar(10) DEFAULT NULL,
  `flat` varchar(10) DEFAULT NULL,
  `bankacc` varchar(20) DEFAULT NULL,
  `bankbic` varchar(9) DEFAULT NULL,
  `workname` varchar(150) DEFAULT NULL,
  `workposition` varchar(100) DEFAULT NULL,
  `workaddress` varchar(100) DEFAULT NULL,
  `workphone` varchar(50) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `inn` varchar(15) DEFAULT NULL,
  `ogrn` varchar(13) DEFAULT NULL,
  `contactname` varchar(100) DEFAULT NULL,
  `contactposition` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (23,'petrov@gmail.com',NULL,'I','A','','Петр','Петрович','Петров','M',NULL,NULL,'2016-08-07 00:00:00','3333333333','petrov@gmail.com',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'admin',NULL,'I','','','','','','',NULL,NULL,'2016-08-07 00:00:00','','2',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'a123','ффф 123','I','A','','ы','в','ф433','M','','','2016-08-08 22:53:43','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,'denzorin112@gmail.com',NULL,'I','','','','','','',NULL,NULL,'2016-08-11 21:44:01','','',NULL,'',NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,'',NULL,'A','A','1234 5678','Иван','Иванович','Иванов','M',NULL,NULL,'2016-10-14 00:00:00','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','',NULL,'','',NULL,NULL,NULL,NULL),(31,'','ИП Ромашка','B',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2016-08-12 00:00:00','77777','88888',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'66666666666666666666','555555555',NULL,NULL,NULL,NULL,'3','4','111111111111111','2222222222222','99999','00000'),(32,'denzorin1',NULL,'I','A','5555 555555','Денис','Валерьевич','Зорин','M',NULL,NULL,'2016-08-12 00:00:00','(916) 123-5467','denzorin1@gmail.com',NULL,'ОВД Лефортово','2003-01-01','Москва','10-я Соколиной горы','12','20','82222222222222222224','722222224',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,'',NULL,'A','A','111133333','Семен','Петрович','Петров','M',NULL,NULL,'2016-08-28 00:00:00','','',NULL,NULL,'2016-08-28',NULL,NULL,NULL,NULL,NULL,NULL,'','','',NULL,'','',NULL,NULL,NULL,NULL),(35,'','ООО Фотобанк','U',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2220-01-01 00:00:00','77777','88888',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'66666666666666666666','555555555',NULL,NULL,NULL,NULL,'3','4','111111111111111','2222222222222',NULL,NULL),(36,'denzorin@yahoo.com',NULL,'I','','','','','','',NULL,NULL,'2016-09-09 00:00:00','','denzorin@yahoo.com',NULL,'','2016-09-09','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38,'denzorin1@gmail.com',NULL,'I',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2016-09-22 00:00:00',NULL,NULL,NULL,NULL,'2016-09-22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deal`
--

DROP TABLE IF EXISTS `deal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idclient` int(11) NOT NULL,
  `idcpty` int(11) NOT NULL,
  `premium` decimal(10,2) NOT NULL,
  `sum` decimal(10,2) NOT NULL,
  `term` int(11) NOT NULL,
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `begindate` date DEFAULT NULL,
  `enddate` date DEFAULT NULL,
  `objectinsurance` varchar(100) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `loss` decimal(10,2) DEFAULT NULL,
  `ourprem` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `DEALCLIENT_FK_idx` (`idclient`),
  KEY `DEALCPTY_FK_idx` (`idcpty`),
  KEY `DEALSTAUS_FK_idx` (`status`),
  CONSTRAINT `DEALCLIENT_FK` FOREIGN KEY (`idclient`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DEALCPTY_FK` FOREIGN KEY (`idcpty`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DEALSTATUS_FK` FOREIGN KEY (`status`) REFERENCES `dealstatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deal`
--

LOCK TABLES `deal` WRITE;
/*!40000 ALTER TABLE `deal` DISABLE KEYS */;
INSERT INTO `deal` VALUES (29,30,31,900.00,90000.00,365,'2016-09-04 00:00:00','2001-01-01','2002-01-01','Объектив Nikon 1575',3,0.00,90.00),(31,30,31,1000.00,10000.00,365,'2016-09-11 00:00:00','2001-01-01','2002-01-01','',2,NULL,100.00),(32,30,31,0.00,0.00,365,'2016-09-29 00:00:00','2016-09-29','2017-09-29','555',2,NULL,NULL),(33,33,31,1000.00,60000.00,89,'2016-10-04 00:00:00','2016-10-04','2017-01-01','333',3,0.00,100.00),(34,33,31,1500.00,50000.00,89,'2016-10-04 00:00:00','2016-10-04','2017-01-01','555',3,0.00,NULL),(35,35,31,700.00,77000.00,89,'2016-10-04 00:00:00','2016-10-04','2017-01-01','777',2,NULL,NULL),(36,30,31,500.00,5000.00,31,'2016-10-09 00:00:00','2016-10-09','2016-11-09','',2,NULL,50.00);
/*!40000 ALTER TABLE `deal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dealstatus`
--

DROP TABLE IF EXISTS `dealstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dealstatus` (
  `id` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dealstatus`
--

LOCK TABLES `dealstatus` WRITE;
/*!40000 ALTER TABLE `dealstatus` DISABLE KEYS */;
INSERT INTO `dealstatus` VALUES (1,'EDIT','Редактируется'),(2,'INVEST','Инвестируется'),(3,'CLOSE','Закрыт'),(4,'CANCEL','Отменен');
/*!40000 ALTER TABLE `dealstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dictionary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `value` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DICTNAME_UIX` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dictionary`
--

LOCK TABLES `dictionary` WRITE;
/*!40000 ALTER TABLE `dictionary` DISABLE KEYS */;
INSERT INTO `dictionary` VALUES (1,'PREMIUM','10','Размер комиссии, %'),(2,'withdrawEmail','denzorin1@gmail.com','withdraw Email'),(3,'withdrawCommission','0.5','Комиссия за вывод, %');
/*!40000 ALTER TABLE `dictionary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation`
--

DROP TABLE IF EXISTS `operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cost` decimal(10,2) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `comment` varchar(250) NOT NULL,
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(10) NOT NULL DEFAULT 'INIT',
  `iduser` int(11) NOT NULL,
  `login` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `OPER_USER_FK_idx` (`iduser`),
  CONSTRAINT `OPER_USER_FK` FOREIGN KEY (`iduser`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation`
--

LOCK TABLES `operation` WRITE;
/*!40000 ALTER TABLE `operation` DISABLE KEYS */;
INSERT INTO `operation` VALUES (52,100.00,'denzorin1:100.00','denzorin1@gmail.com',NULL,'denzorin1:100.00','2016-11-13 21:45:06','INIT',31,'denzorin1'),(53,100.00,'denzorin1:100.00','denzorin1@gmail.com',NULL,'denzorin1:100.00','2016-11-13 21:46:51','INIT',31,'denzorin1'),(54,100.00,'denzorin1:100.00','denzorin1@gmail.com',NULL,'denzorin1:100.00','2016-11-13 21:47:10','INIT',31,'denzorin1'),(55,100.00,'denzorin1:100.00','denzorin1@gmail.com',NULL,'denzorin1:100.00','2016-11-13 21:47:55','INIT',31,'denzorin1'),(56,100.00,'denzorin1:100.00','denzorin1@gmail.com',NULL,'denzorin1:100.00','2016-11-13 21:51:04','INIT',31,'denzorin1'),(57,100.00,'denzorin1:100.00','denzorin1@gmail.com',NULL,'denzorin1:100.00','2016-11-13 22:10:02','INIT',31,'denzorin1'),(58,100.00,'denzorin1:100.00','denzorin1@gmail.com',NULL,'denzorin1:100.00','2016-11-13 22:19:09','ERROR',31,'denzorin1');
/*!40000 ALTER TABLE `operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `middlename` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `digest` varchar(100) DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `regcode` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `admin` int(1) DEFAULT NULL,
  `idclient` int(11) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `seed` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `USERSTATUS_FK_idx` (`status`),
  KEY `USERCLIENT_FK_idx` (`idclient`),
  CONSTRAINT `USERCLIENT_FK` FOREIGN KEY (`idclient`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `USERSTATUS_FK` FOREIGN KEY (`status`) REFERENCES `userstatus` (`code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'a123','a','Артем12','','','9b2767b685ee86e45118cd4ecfa6c9e1634d01ad','2016-07-28 18:33:55',NULL,'INVEST',NULL,25,'1',NULL),(19,'admin','033b71d62c7f56ac25de92da3627559c1bf99f0f0b4247670599429f3763cb5d','Админ','','','c32f5a06c513375a3268de43d079c174c09fb996','2016-11-13 15:23:58','3fff74c42d12417c8272ccc9c8deacb9','INVEST',1,24,'denzorin@yahoo.com','bd9508fb33e00a318ee7040306ba50d5e6a74212dacb833eccb8a1acdd0f2503b12723787c098067979c10e078cb3cf1db2c823540fc283289c7a18d086b64be'),(23,'denzorin112@gmail.com','1','','','','d808e41b51fe5c91d02278bb18b157f346f4dd94','2016-08-01 20:36:19','38a57a2ded844511a41a1a88ea4f3448','INVEST',NULL,28,'3',NULL),(28,'petrov@gmail.com','1','','','qq23','03c93b029e45196fd107ccb1a45a98b091dbc096','2016-09-09 20:10:24','1dc2dec0cb134f829913dded752984a6','REG',NULL,23,'4',NULL),(30,'admin@qq.ru','55471014',NULL,NULL,NULL,NULL,'2016-08-12 20:32:49','a8e17ea6890742309d4c8c5c17c9ffa1','INIT',NULL,NULL,'5',NULL),(31,'denzorin1','de77ab31ef1e58ca1af53a19e7ee479cf8c5cdd2e1f48715a61c14f52a6ad2a4',NULL,NULL,NULL,'ba2959ece5da3098e489b9bd484dae0ef5461fd6','2016-11-13 22:19:09','c3250b7b8a29410a8ab6afbbf2bf794e','INVEST',NULL,32,'denzorin1@gmail.com','1a864acc4bb251ab54297cc1dc54010bbd68f9be1d3f70936dd787b490360b6ac4a3b1cafbb6405fca96da5c8b97adadf24ed539273e46473821421568956173'),(32,'denzorin@yahoo.com','1',NULL,NULL,NULL,'07f3130f04c9f30ef0e6e6da20d3454a705e4831','2016-09-09 23:24:14','acfb3c42f5114ee3b2b84809319db8a5','INVEST',NULL,36,'denzorin11@yahoo.com',NULL),(33,'a@q.ru','01362675',NULL,NULL,NULL,NULL,NULL,'8b445975a834465ba755e91a4fd5f44e','INIT',NULL,NULL,'7',NULL),(34,'q@q.ru','75759735',NULL,NULL,NULL,NULL,NULL,'b00bb811221943ae8dcd0ef488472ec4','INIT',NULL,NULL,'8',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdeals`
--

DROP TABLE IF EXISTS `userdeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userdeals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `iddeal` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `USERDEALS_UNX` (`iduser`,`iddeal`),
  KEY `FK_USERDEALS_USER_idx` (`iduser`),
  KEY `FK_USERDEALS_DEAL_idx` (`iddeal`),
  CONSTRAINT `FK_USERDEALS_DEAL` FOREIGN KEY (`iddeal`) REFERENCES `deal` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USERDEALS_USER` FOREIGN KEY (`iduser`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdeals`
--

LOCK TABLES `userdeals` WRITE;
/*!40000 ALTER TABLE `userdeals` DISABLE KEYS */;
INSERT INTO `userdeals` VALUES (64,31,29),(65,31,33);
/*!40000 ALTER TABLE `userdeals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userstatus`
--

DROP TABLE IF EXISTS `userstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_UNIQUE` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userstatus`
--

LOCK TABLES `userstatus` WRITE;
/*!40000 ALTER TABLE `userstatus` DISABLE KEYS */;
INSERT INTO `userstatus` VALUES (1,'INIT','Неподтветжденный'),(2,'REG','Зарегистрирован'),(3,'INVEST','Проинвестировавший'),(4,'BLOCKED','Заблокирован');
/*!40000 ALTER TABLE `userstatus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-13 22:33:53
