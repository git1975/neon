-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: insure
-- ------------------------------------------------------
-- Server version	5.6.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(20) NOT NULL,
  `isactive` int(11) NOT NULL COMMENT 'счет активный(1) или пассивный(-1)',
  `idparent` int(11) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ACCOUNT_NUMBER` (`number`),
  KEY `ACCOUNT_PARENT_idx` (`idparent`),
  CONSTRAINT `ACCOUNT_PARENT` FOREIGN KEY (`idparent`) REFERENCES `account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'A0002',1,NULL,'Активный счет инвестора'),(2,'A0003',1,NULL,'Счет инвестиций'),(3,'A0001',-1,NULL,'Пассивный счет карты');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting`
--

DROP TABLE IF EXISTS `accounting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddtaccount` int(11) NOT NULL,
  `idktaccount` int(11) NOT NULL,
  `amount` decimal(10,4) NOT NULL,
  `operdate` date NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `desc` varchar(100) DEFAULT NULL,
  `iddeal` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ACCOUNTING_USER_idx` (`iduser`),
  KEY `ACCOUNTING_DT_idx` (`dt`),
  KEY `ACCOUNTING_DTACC_idx` (`iddtaccount`),
  KEY `ACCOUNTING_KTACC_idx` (`idktaccount`),
  KEY `ACCOUNTING_DEAL_idx` (`iddeal`),
  CONSTRAINT `ACCOUNTING_DEAL` FOREIGN KEY (`iddeal`) REFERENCES `deal` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ACCOUNTING_DTACC` FOREIGN KEY (`iddtaccount`) REFERENCES `account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ACCOUNTING_KTACC` FOREIGN KEY (`idktaccount`) REFERENCES `account` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ACCOUNTING_USER` FOREIGN KEY (`iduser`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting`
--

LOCK TABLES `accounting` WRITE;
/*!40000 ALTER TABLE `accounting` DISABLE KEYS */;
INSERT INTO `accounting` VALUES (28,3,1,100.0000,'2001-01-20',1,NULL,'2016-07-24 17:53:37',NULL,NULL),(29,3,1,100.0000,'2001-01-20',1,NULL,'2016-07-24 17:54:20',NULL,NULL),(30,1,2,50.0000,'2001-01-01',1,NULL,'2016-07-24 17:54:42',NULL,NULL),(31,1,2,50.0000,'2001-01-01',1,NULL,'2016-07-24 17:55:04',NULL,NULL),(32,3,1,100.0000,'2016-07-24',1,'a','2016-07-24 18:05:46',NULL,NULL),(33,3,1,100.0000,'2016-07-24',1,'a','2016-07-24 18:05:52',NULL,NULL),(36,3,1,100.0000,'2016-07-24',18,'denzorin@yahoo.com','2016-07-24 23:46:31',NULL,NULL),(37,3,1,100.0000,'2016-07-25',18,'denzorin@yahoo.com','2016-07-25 14:36:13',NULL,NULL),(48,3,1,100.0000,'2016-07-25',19,'admin','2016-07-25 17:04:26',NULL,NULL),(49,3,1,100.0000,'2016-07-25',19,'admin','2016-07-25 19:57:53',NULL,NULL),(50,3,1,100.0000,'2016-08-01',23,'denzorin1@gmail.com','2016-08-01 20:35:02',NULL,NULL),(51,3,1,100.0000,'2016-08-01',28,'denzorin1@gmail.com','2016-08-01 21:43:04',NULL,NULL),(52,3,1,100.0000,'2016-08-17',31,'denzorin1@gmail.com','2016-08-17 22:20:34','1',NULL),(53,1,2,20.0000,'2016-08-17',31,NULL,'2016-08-17 22:21:34','2',NULL),(54,3,1,100.0000,'2016-08-17',31,'denzorin1@gmail.com','2016-08-17 23:18:42',NULL,NULL),(55,1,2,30.0000,'2016-08-18',31,NULL,'2016-08-18 00:16:41',NULL,26),(56,1,2,20.0000,'2016-08-18',31,NULL,'2016-08-18 00:18:01',NULL,26),(57,1,2,10.0000,'2016-08-18',31,NULL,'2016-08-18 00:24:31',NULL,26),(58,1,2,-10.0000,'2016-08-18',31,NULL,'2016-08-18 00:24:40',NULL,26),(59,1,2,10.0000,'2016-08-18',31,NULL,'2016-08-18 00:26:38',NULL,26),(60,1,2,0.0000,'2016-08-18',31,NULL,'2016-08-18 00:26:41',NULL,26),(61,1,2,10.0000,'2016-08-18',31,NULL,'2016-08-18 00:27:12',NULL,26);
/*!40000 ALTER TABLE `accounting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `fullname` varchar(250) DEFAULT NULL,
  `ctp` char(1) NOT NULL,
  `dtp` char(1) DEFAULT NULL,
  `dul` varchar(50) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `middlename` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL COMMENT 'пол',
  `location` varchar(250) DEFAULT NULL COMMENT 'прописка/адрес',
  `bankinfo` varchar(250) DEFAULT NULL COMMENT 'Реквизиты банковского счета',
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата создания',
  `phone` varchar(50) DEFAULT NULL COMMENT 'Телефон',
  `email` varchar(100) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL COMMENT 'Должность',
  `dulkem` varchar(100) DEFAULT NULL,
  `duldt` date DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `dom` varchar(10) DEFAULT NULL,
  `flat` varchar(10) DEFAULT NULL,
  `bankacc` varchar(20) DEFAULT NULL,
  `bankbic` varchar(9) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (23,'denzorin1@gmail.com','','I','B','','Денис','Валерьевич','Зорин','F','1','2','2016-08-07 23:25:47','3','4','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'admin',NULL,'I',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2016-08-07 23:49:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'a123','ффф 123','I','A','','ы','в','ф433','M','','','2016-08-08 22:53:43','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,'denzorin@yahoo.com','','I','A','','','','','','','','2016-08-08 23:05:04','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,'denzorin112@gmail.com','','I','','','','','','','','','2016-08-11 21:44:01','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,'','Иванов Иван','A','A','1234 5678','Иван','Иванович','Иванов','M','','','2016-08-12 19:45:23','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,'','ИП Ромашка','B','','','','','','','','','2016-08-12 19:45:46','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,'denzorin1@gmail.com',NULL,'I','A','1143321412','Денис','Валерьевич','Зорин','M',NULL,NULL,'2016-08-12 20:41:03','9161234567','denzorin1@gmail.com',NULL,'ОВД Лефортово','2004-02-29','Москва','10-я Соколиной горы','12','20','82222222222222222222','722222222');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deal`
--

DROP TABLE IF EXISTS `deal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idclient` int(11) NOT NULL,
  `idcpty` int(11) NOT NULL,
  `premium` decimal(10,2) NOT NULL,
  `sum` decimal(10,2) NOT NULL,
  `term` int(11) NOT NULL,
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `objectinsurance` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `DEALCLIENT_FK_idx` (`idclient`),
  KEY `DEALCPTY_FK_idx` (`idcpty`),
  CONSTRAINT `DEALCLIENT_FK` FOREIGN KEY (`idclient`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DEALCPTY_FK` FOREIGN KEY (`idcpty`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deal`
--

LOCK TABLES `deal` WRITE;
/*!40000 ALTER TABLE `deal` DISABLE KEYS */;
INSERT INTO `deal` VALUES (26,30,31,2000.00,50000.00,3,'2016-08-14 19:38:05','Фотоаппарат');
/*!40000 ALTER TABLE `deal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `middlename` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `digest` varchar(100) DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `regcode` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `admin` int(1) DEFAULT NULL,
  `idclient` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  KEY `USERSTATUS_FK_idx` (`status`),
  KEY `USERCLIENT_FK_idx` (`idclient`),
  CONSTRAINT `USERCLIENT_FK` FOREIGN KEY (`idclient`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `USERSTATUS_FK` FOREIGN KEY (`status`) REFERENCES `userstatus` (`code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'a123','a','Артем12','','','9b2767b685ee86e45118cd4ecfa6c9e1634d01ad','2016-07-28 18:33:55',NULL,'INVEST',NULL,25),(18,'denzorin@yahoo.com','123','','','','fd2951a97c8f7d456d87032275b790daef0d3a2b','2016-07-25 15:22:06','9a73e53972b44bd9b4967e6cdc157e3d','REG',NULL,26),(19,'admin','1','Админ','','','ee308838f6ae4a91a3d1804f1ee2f98b382e0b29','2016-08-19 20:12:24',NULL,'INVEST',1,24),(23,'denzorin11@gmail.com','1','','','','d808e41b51fe5c91d02278bb18b157f346f4dd94','2016-08-01 20:36:19','38a57a2ded844511a41a1a88ea4f3448','INVEST',NULL,28),(28,'denzorin12@gmail.com','1','','','qq23','51793a192db25660c822abb64c52690fd349da5e','2016-08-12 20:33:09','1dc2dec0cb134f829913dded752984a6','REG',NULL,23),(30,'admin@qq.ru','55471014',NULL,NULL,NULL,NULL,'2016-08-12 20:32:49','a8e17ea6890742309d4c8c5c17c9ffa1','INIT',NULL,NULL),(31,'denzorin1@gmail.com','1',NULL,NULL,NULL,'390bc649be217beb6b4fffd068fbdb61d8a25ef7','2016-08-19 20:11:48','eaf06075c8524abca46320002446e38d','REG',NULL,32);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdeals`
--

DROP TABLE IF EXISTS `userdeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userdeals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `iddeal` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `USERDEALS_UNX` (`iduser`,`iddeal`),
  KEY `FK_USERDEALS_USER_idx` (`iduser`),
  KEY `FK_USERDEALS_DEAL_idx` (`iddeal`),
  CONSTRAINT `FK_USERDEALS_DEAL` FOREIGN KEY (`iddeal`) REFERENCES `deal` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USERDEALS_USER` FOREIGN KEY (`iduser`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdeals`
--

LOCK TABLES `userdeals` WRITE;
/*!40000 ALTER TABLE `userdeals` DISABLE KEYS */;
INSERT INTO `userdeals` VALUES (44,31,26);
/*!40000 ALTER TABLE `userdeals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userstatus`
--

DROP TABLE IF EXISTS `userstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_UNIQUE` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userstatus`
--

LOCK TABLES `userstatus` WRITE;
/*!40000 ALTER TABLE `userstatus` DISABLE KEYS */;
INSERT INTO `userstatus` VALUES (1,'INIT','Неподтветжденный'),(2,'REG','Зарегистрирован'),(3,'INVEST','Проинвестировавший'),(4,'BLOCKED','Заблокирован');
/*!40000 ALTER TABLE `userstatus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-19 20:46:20
