'use strict';

var JInsurionTab = React.createClass({
	displayName : 'JInsurionTab',

	getDefaultProps : function() {
		return {};
	},

	getInitialState : function() {
		return {
		};
	},
	
	childUpdated : function() {
		var key = Math.random();
		this.setState({ key: Math.random()});
	},
	
	render : function() {
		return (
				React.DOM.div({className:'div-main-child'}, 
						JTitleDiv({display:'block', title:'Данные счета'}, 
								JDictList({key:this.state.key})
						),
						JTitleDiv({display:'block', title:'Сумма комиссии'}, 
								JRepComm({key:this.state.key})
						),
						JTitleDiv({display:'block', title:'Остатки'}, 
								JSaldos({key:this.state.key})
						)
				)
		)
	}
});
JInsurionTab = React.createFactory(JInsurionTab);

var JRepComm = React.createClass({
	displayName : 'JRepComm',

	getDefaultProps : function() {
		return {readonly:false, f:[{name:'sum', id:'sum'}, {name:'month', id:'num'}, {name:'year', id:'num'}],
		        cols: [{name:'Сумма'}, {name:'Месяц'}, {name:'Год'}]
		       };
	},

	getInitialState : function() {
		return {
			loading: false
		};
	},

	loadData : function() {
		var self = this;
		self.setState({loading:true});
		Rest.ajax2({method: "repcomm"}, function(data) {
			self.setState({rows: data});
			self.setState({loading:false});
		}, function(data) {
			self.setState({loading:false});
		});
	},

	componentWillMount : function() {
		this.loadData();
	},
	
	childUpdated : function() {
	},
	
	rowClicked : function(row) {
		if(row && this.state.rowId == row.id){
			this.setState({rowId:'0'});
		} else {
			this.setState({rowId:row.id});
		}
		if(this.props.rowClicked){
			this.props.rowClicked(row);
		}
	},

	render : function() {
		if (this.state.loading) {
			return JControlLoading({loading:this.state.loading});
		}
		var self = this;
		return (React.DOM.div(null, 
				JTable({rows: this.state.rows, f: this.props.f, cols: this.props.cols, readonly:true, rowClicked: this.rowClicked, childUpdated:this.childUpdated})
		));
	}
});
JRepComm = React.createFactory(JRepComm);