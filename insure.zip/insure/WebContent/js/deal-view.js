'use strict';

var JDealView = React.createClass({
	displayName : 'JDealView',

	getDefaultProps : function() {
		return {};
	},

	getInitialState : function() {
		return {loading:false};
	},

	doCancel : function() {
		if(this.props.childUpdated){
			this.props.childUpdated();
		}
	},
	
	render : function() {
		var row = this.props.row;
		var readonly = true;
		return (
				JModalContainer({key: this.state.key}, close, 
						JTitleDiv({title:'Данные Риска'}, 
							//JSelect({ref : 'status', name:'Статус Риска', defaultValue:row.status.id, readonly:readonly, data:[{key:'1', value: 'Редактируется'}, {key:'2', value: 'Инвестирован'}, {key:'3', value: 'Завершен'}, {key:'4', value: 'Отменен'}]}),
							JInputText({ref : 'status', name:'Статус Риска', defaultValue:row.status.name, readonly:readonly, underline:true}),
							JMaskedDate({ref : 'createdate', name:'Дата создания', defaultValue:(row && row.id)?row.createdate:moment().format('DD.MM.YYYY'), id:'dt_createdate', readonly:readonly, underline:true}),
							JInputText({ref : 'idclient', name:'Клиент', defaultValue:row.client.fio, readonly:readonly, underline:true}),
							JInputText({ref : 'idcpty', name:'Агент', defaultValue:row.cpty.fullname, readonly:readonly, underline:true}),
							JInputText({ref : 'sum', name:'Страховая сумма, руб.', defaultValue:num2(row.sum), readonly:readonly, underline:true}),
							JInputText({ref : 'premium', name:'Страховая премия, руб.', defaultValue:num2(row.premium), readonly:readonly, underline:true}),
							JMaskedDate({ref : 'begindate', name:'Дата начала Риска', defaultValue:(row && row.id)?row.begindate:moment().format('DD.MM.YYYY'), id:'dt_begindate', readonly:readonly, underline:true}),
							JMaskedDate({ref : 'enddate', name:'Дата завершения Риска', defaultValue:row.enddate, id:'dt_enddate', readonly:readonly, underline:true}),
							JInputText({ref : 'term', name:'Срок', defaultValue:row.term, readonly:true, underline:true}),
							JInputText({ref : 'objectinsurance', name:'Объект страхования', defaultValue:row.objectinsurance, readonly:readonly, underline:true})
						),
							JButton({style:{display:'block', width:'70pt'}, onClick : this.doCancel, caption:'Отмена'})
		))
	}
});
JDealView = React.createFactory(JDealView);
